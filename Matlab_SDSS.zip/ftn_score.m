function [score_forest, score_food, score_water] = ftn_score(boar_x,boar_y,sensing_r,Map_forest, Map_food, Map_water)

score_forest = zeros(3);
[num_forest] = ftn_sensing(boar_x-1, boar_y+1,sensing_r,Map_forest); score_forest(1,1)= num_forest;
[num_forest] = ftn_sensing(boar_x-1, boar_y+0,sensing_r,Map_forest); score_forest(2,1)= num_forest;
[num_forest] = ftn_sensing(boar_x-1, boar_y-1,sensing_r,Map_forest); score_forest(3,1)= num_forest;
[num_forest] = ftn_sensing(boar_x+0, boar_y+1,sensing_r,Map_forest); score_forest(1,2)= num_forest;
[num_forest] = ftn_sensing(boar_x+0, boar_y+0,sensing_r,Map_forest); score_forest(2,2)= num_forest;
[num_forest] = ftn_sensing(boar_x+0, boar_y-1,sensing_r,Map_forest); score_forest(3,2)= num_forest;
[num_forest] = ftn_sensing(boar_x+1, boar_y+1,sensing_r,Map_forest); score_forest(1,3)= num_forest;
[num_forest] = ftn_sensing(boar_x+1, boar_y+0,sensing_r,Map_forest); score_forest(2,3)= num_forest;
[num_forest] = ftn_sensing(boar_x+1, boar_y-1,sensing_r,Map_forest); score_forest(3,3)= num_forest;

score_food = zeros(3);
[num_food] = ftn_sensing(boar_x-1, boar_y+1,sensing_r,Map_food); score_food(1,1)= num_food;
[num_food] = ftn_sensing(boar_x-1, boar_y+0,sensing_r,Map_food); score_food(2,1)= num_food;
[num_food] = ftn_sensing(boar_x-1, boar_y-1,sensing_r,Map_food); score_food(3,1)= num_food;
[num_food] = ftn_sensing(boar_x+0, boar_y+1,sensing_r,Map_food); score_food(1,2)= num_food;
[num_food] = ftn_sensing(boar_x+0, boar_y+0,sensing_r,Map_food); score_food(2,2)= num_food;
[num_food] = ftn_sensing(boar_x+0, boar_y-1,sensing_r,Map_food); score_food(3,2)= num_food;
[num_food] = ftn_sensing(boar_x+1, boar_y+1,sensing_r,Map_food); score_food(1,3)= num_food;
[num_food] = ftn_sensing(boar_x+1, boar_y+0,sensing_r,Map_food); score_food(2,3)= num_food;
[num_food] = ftn_sensing(boar_x+1, boar_y-1,sensing_r,Map_food); score_food(3,3)= num_food;

score_water = zeros(3);
[num_water] = ftn_sensing(boar_x-1, boar_y+1,sensing_r,Map_water); score_water(1,1)= num_water;
[num_water] = ftn_sensing(boar_x-1, boar_y+0,sensing_r,Map_water); score_water(2,1)= num_water;
[num_water] = ftn_sensing(boar_x-1, boar_y-1,sensing_r,Map_water); score_water(3,1)= num_water;
[num_water] = ftn_sensing(boar_x+0, boar_y+1,sensing_r,Map_water); score_water(1,2)= num_water;
[num_water] = ftn_sensing(boar_x+0, boar_y+0,sensing_r,Map_water); score_water(2,2)= num_water;
[num_water] = ftn_sensing(boar_x+0, boar_y-1,sensing_r,Map_water); score_water(3,2)= num_water;
[num_water] = ftn_sensing(boar_x+1, boar_y+1,sensing_r,Map_water); score_water(1,3)= num_water;
[num_water] = ftn_sensing(boar_x+1, boar_y+0,sensing_r,Map_water); score_water(2,3)= num_water;
[num_water] = ftn_sensing(boar_x+1, boar_y-1,sensing_r,Map_water); score_water(3,3)= num_water;
