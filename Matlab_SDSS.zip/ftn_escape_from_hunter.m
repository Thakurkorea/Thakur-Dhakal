function  [boar_x, boar_y] = ftn_escape_from_hunter(boar_x, boar_y,sensing_r_hunter,hunter,num_hunter, deg_escape_hunter)
% �Ÿ�r �̳��� ��ġ�ϰ� �ִ� ��ɲ۵��� ��ġ�� 1/r^2 ������ ������ �̵�
% boar_x = boar(num).position(1);
% boar_y = boar(num).position(2);
r = sensing_r_hunter;
temp =[];
 
 n = num_hunter;
 temp = hunter;
s=0; death_index=[];
 for i=1:n
   if ((boar_x-hunter(i).position(1))^2 + (boar_y-hunter(i).position(2))^2 > r^2 )
     s = s + 1;
     death_index(s,1) = i;
   end
 end
 temp(death_index) =[];

 
 [z, n1] = size(temp);
 
if n1 == 0 
    return; 
end

 tpx = 0; tpy = 0;

 for i=1:n1
    
     temp(i).position(1) = temp(i).position(1) - boar_x; 
     temp(i).position(2) = temp(i).position(2) - boar_y; 
     
     rt = norm([temp(i).position(1) temp(i).position(2)]);  
     
     if rt == 0 rt = 1;end % ��ĥ�� ���ϱ� 
     
     temp(i).position(1) = - temp(i).position(1)/rt^2; 
     temp(i).position(2) = - temp(i).position(2)/rt^2;   
    
     tpx = tpx + temp(i).position(1);
     tpy = tpy + temp(i).position(2);
 end

 
b1 = deg_escape_hunter*tpx + boar_x;
b2 = deg_escape_hunter*tpy + boar_y; 
 
boar_x = round(b1);
boar_y = round(b2);

end

