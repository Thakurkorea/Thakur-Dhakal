clear all;
load boar_appearance.mat;
n = 0;
for k =12.01:0.01:12.31
    n=n+1;
a12(n,1) = length(find(boar_appearance==k));
end 
n = 0;
for k =11.01:0.01:11.30
    n=n+1;
a11(n,1) = length(find(boar_appearance==k));
end 
n = 0;
for k =10.01:0.01:10.31
    n=n+1;
a10(n,1) = length(find(boar_appearance==k));
end 
n = 0;
for k =1.01:0.01:1.31
    n=n+1;
a1(n,1) = length(find(boar_appearance==k));
end
n = 0;
for k =2.01:0.01:2.29
    n=n+1;
a2(n,1) = length(find(boar_appearance==k));
end
n = 0;
for k =3.01:0.01:3.31
    n=n+1;
a3(n,1) = length(find(boar_appearance==k));
end

a=[a1; a2; a3; a10; a11; a12];
