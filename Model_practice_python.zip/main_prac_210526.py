# -*- coding: utf-8 -*-
"""
Set attributs id,pos_x,pos_y, age, sex,fertility, pregnant, pregnancy, status, offspring,death,num,month
Consider birth rate
consider carrying capacity
consider allee effect
consider long and short move
consider movement pattern using HMM from observed data
consider groupinig
consider infection period =1 week
immune accoured after 3 weeks from infection 
infected host refection infecious until death
carcass removal is considered 
hunting effect considered 

@author: brook
"""
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
import numpy as np
from numpy import random as rand
from celluloid import Camera
#from matplotlib.animation import FuncAnimation,PillowWriter,ArtistAnimation
from matplotlib import style
import math
import copy
#from scipy import stats
import os, sys
import ffmpeg
import seaborn as sns
import geopandas as gpd
import pandas as pd
from shapely.geometry import Point, Polygon
import descartes
style.use('seaborn-whitegrid')
sns.set()
from  map_and_movement import*
import time
import folium
from celluloid import Camera
from selenium import webdriver
import plotly.express as px
from plotly.offline import download_plotlyjs, init_notebook_mode,  plot,plot_mpl
from plotly.io import write_image 
from plotly.io import to_image
from IPython.display import Image
# init_notebook_mode()
init_notebook_mode(connected=True)
start=time.time()

class Boar:
    col={'male':['#0D39EA'], 'female': ['#f70af7'], 'liter':['#339273'], 'suspectible': ['#f2f542'], 'infected':['#F31F35'], 'death':['#060505'] }           # color of different individuals
    # blue,pink,green, yellow,red,black
    #age_ratio={0.50:[0,12],	0.27:[13,24],0.23:[24,170]}
   
    def __init__(self,id,pos_x,pos_y, age, sex,fertility, pregnant, pregnancy, offspring,status,death,month,season, group, repeat,num):
        self.id=id
        self.pos_x=pos_x
        self.pos_y=pos_y
        self.age=age                          # age in month
        self.sex=sex
        self.fertility=fertility              # fertility popwer (yes, no, female_fert %)
        self.pregnant=pregnant
        self.pregnancy=pregnancy
        self.status=status                    # health status 'suspectible','infected','Removed'
        self.offspring=offspring              # have baby or not
        self.death=death
        self.month=month
        self.season=season
        self.color=[]
        self.group=group
        self.repeat=repeat
        self.num=num
        self.mate_time=[]   
        self.pregnancy_time=[]              # laying baby period
        self.lStage=[]                      #life state liter, yourng, old
        self .habi_seq=[]                   # possible move habitat sequences 
       
       
    def move_seq(self,TPM,EPM,tot_itr):
        habi_alphabet = ["P1"],["P2"] ,["P3"],["P4"],["P7"],["P8"] # The alphabet of emission
        states = len(EPM)# The no of the states 
        current_state=rand.choice(states,1)[0]                          
        TPM=TPM/(TPM.sum(axis=1,keepdims=1))
        EPM=EPM/(EPM.sum(axis=1,keepdims=1))
        simulated_sites = [] # start with an empty sequence
        #simulated_states =[current_state] # to record the sequence of stat
        for i in range(tot_itr):
            current_state = rand.choice(states, p = TPM[current_state])
            # choose a new state at site i, weighted by the emission probability matrix
            habi = rand.choice(len(habi_alphabet), p = EPM[current_state])
            #simulated_states.append([current_state])
            simulated_sites.append(habi_alphabet[habi])
            self.habi_seq=simulated_sites
        return self.habi_seq
    # def HMM_move(self,itern):
    #     if self.habi_seq[itern]==['P1']:]
    
    def neighbour(self,boars,neigh_radius):
        cont=0     #counting the neighbours
        neighbours=[]
        for ii in range(len(boars)):
            if self.id!=boars[ii].id:
                 distance=math.dist([self.pos_x,self.pos_y],[boars[ii].pos_x,boars[ii].pos_y])   
                 if distance<=neigh_radius:
                     cont+=1
                     neighbours.append(boars[ii])
        return cont, neighbours  
    
    def det_gender(self,R):          # R is male-female ration [ro, 1-ro]
        gender=['male','female']
        self.sex= rand.choice(gender, p = R)

 
    def det_init_status(self,transmission_rate):
         Status=['suspectible','infected','removed']
         if rand.random()< transmission_rate or self.age==0:   # 0.030 % 
                 self.status= Status[1]
         else:
             self.status= Status[0] 
             
     #check fertility status        
    def det_fertility(self, min_mating_age,fertility_rate):                   #FR: fertility rate and determine  
        #mating_season=input("mating_season('winter','spring','summer','autumn')")
        if int(self.age)>=min_mating_age and self.sex=='female' and self.season=='autumn' and rand.random()<=fertility_rate:
            self.fertility ='True'
            
        else:
            self.fertility ='False'
    # determine pregnant            
    def det_pregnant(self, pregnant_rate):
        if self.fertility=='True' and rand.random()<=pregnant_rate:
            self.pregnant='True'
            self.mate_time=boar.repeat
        else:
            self.pregnant='False'
            self.mate_time='None'
                
    # determine pregnancy    
    def det_pregnancy(self, gastation_time):
        if self.pregnant=='True' and self.repeat==(int(gastation_time)+int(self.mate_time)):
            self.pregnancy_time=self.repeat
            self.pregnancy='True'
                    
        else:
            self.pregnancy_time='None'
            self.pregnancy='False'   
     # produce baby     
    def give_birth(self, offs_range,offs_prob,pregnancy_period):         # offspring range and probabilities, period
         if self.pregnancy=='True' and self.pregnancy_time<=self.repeat<=(self.pregnancy_time+pregnancy_period):
            self.offspring= rand.choice(offs_range, p = offs_prob)
         elif  self.sex=='female' and self.age>=6 and rand.random()>=0.5:                                                              #neeed to be refiined
            self.offspring=self.offspring= rand.choice(offs_range, p = offs_prob)
         else:
             self.offspring=0
         liters=[]
         for child in range(self.offspring):
            baby=Boar(self.id,self.pos_x,self.pos_y,0,[],0,0,0,child,'healthy','False',[],[],'baby',self.repeat,[len(boars)+1])
            baby.pos_x=get_rand(Plot_size[0])
            baby.pos_y=get_rand(Plot_size[1])
            baby.det_gender(sex_ratio)
            baby.month=self.month
            baby.season=self.season
            baby.lStage='liter'
            baby.habi_seq[self.repeat:]=baby.move_seq(TPM,EPM,(simulation_time-self.repeat))
            # baby.habi_seq=baby.move_seq(TPM,EPM,(simulation_time-self.repeat))
            # baby.habi_seq=self.habi_seq
            baby.set_color()        
            liters.append(baby)
            child=copy.deepcopy(baby)
            boars.append(child)
    def det_death(self):
        if self.status=='removed':
            self.death='true'
        elif self.age>=max_life_span:
            self.death='true'
        else:
            self.death='false'

    def set_color(self):
        if self.sex=='male':
            self.color=Boar.col['male']
        else:
             self.color=Boar.col['female']
        if self.lStage=='liter':
            self.color=Boar.col['liter']
        # if self.status=='suspectible':
        #     self.color=Boar.col['suspectible']
        if self.status=='infected':
            self.color=Boar.col['infected']   
        if self.death=='True':
             self.color=Boar.col['death']   
          
# class Liter(Boar):
#         def __init__super__


# def det_month(iteration,this_month,age_count):        # determine the month for simulation
def det_month(self,iteration,this_month):        # determine the month for simulation
    months = ['January', 'February', 'March', 'April', 'May', 'June', 'July',
          'August', 'September', 'October', 'November', 'December']
   
    month_idenitfer=int((this_month-1+iteration*12/365)%12)
    month=months[month_idenitfer]
    age_count=(iteration//(365/12))                            #how old is the boar
    self.month=month
    # self.age=age_count+self.age
def det_season(self,month):                      # determine the season based on month
    if month in ('January', 'February', 'March'):
    	season = 'winter'
    elif month in ('April', 'May', 'June'):
    	season = 'spring'
    elif month in ('July', 'August', 'September'):
    	season = 'summer'
    else:
    	season = 'autumn'
    self.season=season

def get_age(self,age_ratio):           # function for initial age determine
    ini_age=age_ratio[rand.choice(list(age_ratio),p=list(age_ratio))]
    self.age=rand.choice(range(ini_age[0],ini_age[1]))
                  
def carry_capa(cont,neighbours,carry_cap_num,boars):
    if cont>=carry_cap_num:
        death_due_carr_cap=cont-carry_cap_num
        death_ind=rand.choice(neighbours,death_due_carr_cap)  #death individual due to carrying capacity
        print(death_ind)
        for n in range(len(death_ind)):
             for boar in boars:
                if boar.num==death_ind[n].num:                              
                    boars.remove(boar)
        return boars            
    else:
        pass              
def allee_capa(boars,allee_num,allee_radius):
   for boar in boars:
       [allee_count, neig]=boar.neighbour(boars,allee_radius)
       if allee_count<=allee_num:
           print('There are just {} boars need more mangement to increase growth'.format(allee_count))
       else:
            pass 
        
# =============================================================================
# # def Plot_ind(boars,t):
# #         xycolor={'x':[],'y':[],'colr':[],'text':[],'sexx':[]}
# #         for boar in boars:
# #             [GX,GY]=Geocoordinates(boar.pos_x, boar.pos_y,extent['xmin'],extent['ymin'],extent['dx'],extent['dy'])
# #             xycolor['x'].append(GX)
# #             xycolor['y'].append(GY)
# #             xycolor['colr'].append(boar.color[0])
# #             xycolor['text'].append(boar.lStage)
# #             xycolor['sexx'].append(boar.sex)
#             
# #         fig = px.scatter_mapbox(xycolor, lat="y", lon="x",zoom=12,color="colr",hover_name="text",labels={"Sex":"Gender","colr": "Color"}, height=400,width=500)
# #         # fig.update_layout(mapbox_style='carto-positron')
# #         fig.update_layout(mapbox_style="open-street-map")
# #         fig.update_layout(margin={"r":0,"t":0,"l":0,"b":0})
# #         fig.layout.update(showlegend=True)
# #         fig.update_layout( title='Boar_simulation', autosize=True)
# #         fig.update_layout(legend=dict(yanchor="top",y=0.99, xanchor="left", x=0.01))
# #         fig.update_layout(showlegend=False)
# #         #crs is EPSG:3857
# #         # fig.show()    
# #         plot(fig,auto_open=True,filename="simtime={} and {}.html".format(t,len(boars)))
 #          plot(fig,auto_open=True,image='png',image_filename=filename,validate=False,auto_play=True,show_link=False,filename=filename)
# #         # cropped_image=pimg(fig,"fine",format="png")
# #         # plt.imshow(cropped_image)
# =============================================================================

# def plot_to_image(fig):
#     if not os.path.exists("images"):
#         os.mkdir("images")
#         fig.ping(f"images/fig{t}.png")
#         img_bytes = fig.to_image(format="png")
#         plt.imshow(img_bytes)
#         Image(img_bytes)
# def Plot_ind(boars,t):          #folium use 
        
#         xycolor={'x':[],'y':[],'colr':[],'text':[],'sexx':[]}
#         for boar in boars:
#             [GX,GY]=Geocoordinates(boar.pos_x, boar.pos_y,extent['xmin'],extent['ymin'],extent['dx'],extent['dy'])
#             xycolor['x'].append(GX)
#             xycolor['y'].append(GY)
#             xycolor['colr'].append(boar.color[0])
#             xycolor['text'].append(boar.lStage)
#             xycolor['sexx'].append(boar.sex)
            
#         fig = px.scatter_mapbox(xycolor, lat="y", lon="x",zoom=12,color="colr",hover_name="text",labels={"Sex":"Gender","colr": "Color"}, height=400,width=500)
#         # camera = Camera(fig)
#         # fig.update_layout(mapbox_style='carto-positron')
#         fig.update_layout(mapbox_style="open-street-map")
#         fig.update_layout(margin={"r":0,"t":0,"l":0,"b":0})
#         fig.layout.update(showlegend=True)
#         fig.update_layout( title='Boar_simulation', autosize=True)
#         fig.update_layout(legend=dict(yanchor="top",y=0.99, xanchor="left", x=0.01))
#         fig.update_layout(showlegend=False)
#         #crs is EPSG:3857
#         fig.show()   
#         # camera.snap()
#         filename="simtime={} and {}.html".format(t,len(boars))
#         plot(fig,auto_open=True,image='png',image_filename=filename,validate=False,auto_play=True,show_link=False,filename=filename)

'''
Plot the boars in each time scan the figure and present total population with scatter diagram in real map

'''
def Plot_ind(boars,t):          #folium use 
        
        xycolor={'x':[],'y':[],'colr':[],'text':[],'sexx':[]}
        for boar in boars:
            [GX,GY]=Geocoordinates(boar.pos_x, boar.pos_y,extent['xmin'],extent['ymin'],extent['dx'],extent['dy'])
            xycolor['x'].append(GX)
            xycolor['y'].append(GY)
            xycolor['colr'].append(boar.color[0])
            xycolor['text'].append(boar.lStage)
            xycolor['sexx'].append(boar.sex)
            
        








# initialize and assign the individuals 

# Plot_size=[310,480]
Plot_size=Map_total.shape
max_life_span=170          #month
sex_ratio=[0.45,0.55]       # sex ratio
age_ratio={0.50:[1,12],	0.27:[13,24],0.23:[24,170]}  #month # percentage:[age limit]#https://link.springer.com/content/pdf/10.1007/s10344-014-0867-3.pdf
offs_range = np.arange(0,9)
offs_prob= [0.012, 0.073, 0.165, 0.242, 0.242, 0.165, 0.073, 0.024, 0.004]; #실험값참조
# this_month=input('what month is it (1-12):')        # use input current month
this_month=1                                   #January(1)
fertility_rate=0.65                                 # fertility rate
cont_range=3                                        # contact range distance 3 units
transmission_rate=0.03                              # initial disease transmission rate

min_mating_age=6                                    #month
pregnant_rate=0.8
gastation_time=114
pregnancy_period=2                                  #month

long_mu =20
long_sigma=5
short_mu=6
short_sigma=3
LS_prob=[0.2,0.8]    # long short probability
#####

TPM=np.array([
    [0.84, 0.14, 0.02],
    [0.05, 0.91,0.04],
    [0.18,0.39,0.43]])
EPM=np.array([
[0.08,0.21,0.61,0.02,0,0.08],
[0.94,0,0.05,0,0,0],
[0.29,0,0.04,0,0.66,0]])
neigh_radius=10  #neighbour radius 
allee_num=2      # allee number
allee_radius=200  # radius of allee effect applied area 
carry_cap_num=10  # carrying capacity number

extent={'xmin':127.95270,'ymin':37.60007071,'dx':0.001,'dy':0.001}  ##crs is EPSG:3857
initial_boars=5
simulation_time=5
pop=[]      # total population
tim=[]      # to save current simulation time

boars=[]    # updated boars
record_boars=[]        # black box to record all boars

def initialize_boars(t=0):
    init_ind=initial_boars
    for i in range(init_ind):
        boar=Boar(i,get_rand(Plot_size[0]),get_rand(Plot_size[1]),[],[],[],[],[],[],[],[],[],[],[],t,[])
        get_age(boar,age_ratio)
        boar.det_gender(sex_ratio)
        boar.det_fertility(min_mating_age,fertility_rate)
        boar.det_pregnant(pregnant_rate)
        boar.det_pregnancy(gastation_time)
        #boar.give_birth(offs_range,offs_prob,pregnancy_period)
        det_month(boar,t, this_month)                          #age, month, season
        boar.det_death()
        boar.det_init_status(transmission_rate)
        boar.gropu=[]
        boar.set_color()
        boar.move_seq(TPM,EPM,simulation_time)
        boar.num=len(boars)+1
        boars.append(boar)
        rec_boar=copy.deepcopy(boar)                    #deep copy for black box save
        record_boars.append(rec_boar)
        # print(boar.id,boar.age, boar.pos_x,boar.pos_y,boar.num)
        
    # for ii in range(len(boars)):
    #     plt.scatter(boars[ii].pos_x,boars[ii].pos_y,c=boars[ii].color)
    # plt.title('Boars in Environment at t=0')
    # # plt.pause(1)
    # plt.show()
    Plot_ind(boars,t)
def update_liters(boars):
    ids=[]
    for boar in boars:
        ids.append(boar.id)
        if boar.lStage=='liter' and boar.age>2:
            boar.id=(np.max(ids))+1
            boar.lStage='young'
            
def update_boars(simulation_time,boars):
    for t in range(1,simulation_time):
        for boar in boars:
            move_dist=move_distance(boar,LS_prob,long_mu,long_sigma,short_mu,short_sigma)
            boar.id=boar.id
            move_ind(boar,t,move_dist,Map_total)
            
            # if boar.lStage!='liter':
            #     move_ind(boar,t,move_dist,Map_total)
            # # else:
            #     for i in range(len(boars)):
            #         if boar.id==boars[i].id:
            #             boar.pos_x=boars[i].pos_x
            #             boar.pos_y=boars[i].pos_y
              
            # # boar.pos_x= get_rand(Plot_size[0])
            # # boar.pos_y=get_rand(Plot_size[1])
            boar.sex=boar.sex
            boar.fertility=boar.det_fertility(min_mating_age,fertility_rate)
            boar.pregnant=boar.det_pregnant(pregnant_rate)
            boar.pregnancy=boar.det_pregnancy(gastation_time)
            boar.offspring=boar.give_birth(offs_range,offs_prob,pregnancy_period)
            boar.status= boar.det_init_status(transmission_rate)
            boar.death= boar.det_death()            
            boar.age+=1
            boar.month= det_month(boar,t, this_month)
            update_liters(boars)                          # checking the liters status and update the id and points
            boar.group=[]          
            boar.repeat=t
            # boar.num=boar.num
            boar.num=len(boars)
            boar.set_color()
            rec_boar=copy.deepcopy(boar)                    #deep copy for black box save
            record_boars.append(rec_boar)
            # print(boar.id,boar.age, boar.pos_x,boar.pos_y,boar.num)
        #     plt.scatter(int(boar.id),int(boar.age))
        #     plt.xlabel("Boar_id")
        #     plt.ylabel('Age (Month)')
        #     plt.title(('ID vs Age at {}'.format(t)))
        # # for ii in range(len(boars)):            
        #     plt.scatter(boars[ii].pos_x,boars[ii].pos_y,c=boars[ii].color)
        #     x=boars[ii].pos_x*0.0003+127.817927
        #     y=boars[ii].pos_y+0.0003+37.628457
        #     # map = folium.Map(location=[x,y], zoom_start=0)
        #     # Hwmap=gpd.read_files(gpd.datasets.get_path('naturalearth_lowres'))
        #     plt.imshow(img2)
        # plt.title('Boars in Environment at t={}'.format(t))
        # # plt.pause(1)
        # plt.show()
        # map
      
        # plt.show()
        Plot_ind(boars,t)
        print(len(boars))
       
    
        # print(len(boars))       


initialize_boars()
print('this is field boars')
update_boars(simulation_time,boars)


# for boar in record_boars:
#     print(boar.id,boar.pos_x,boar.pos_y,boar.age,                         
#         boar.sex,
#         boar.fertility,             
#         boar.pregnant,
#         boar.pregnancy,
#         boar.status,
#         boar.offspring,
#         boar.death,
#         boar.month,
#         boar.season,
#         boar.color,
#         boar.group,
#         boar.repeat,
#         boar.num,
#         boar.mate_time,
#         boar.pregnancy_time)

# boar.__dict__
end=time.time()
print(f"Runtime of the program is {end - start}")