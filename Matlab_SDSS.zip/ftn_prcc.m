% function =  ftn_prcc()
% ��Ʈ�� �Լ� partialcorr()�� PRCC �̴�. 


X = rand(5,3);
[A,pval] = corr(X, 'Type','Spearman');
detA = det(A);
invA = inv(A);
cofactorA = transpose(detA*invA);
cof=ftn_cofactor(A);

P12 = cof(1,2);
P11 = cof(1,1);
P22 = cof(2,2);

rho12 = -P12/(sqrt(P11*P22));
rho = partialcorr(X,'Type','Spearman');

%---------------------------------------------
load hospital ;
hospital.SexID = grp2idx (hospital.Sex);

x = [hospital.SexID hospital.Age hospital.Smoker hospital.Weight];

rho = partialcorr(x,'Type','Spearman');
rho = partialcorr(x,'Type','Pearson');
[rho,pval] = corr(x(:,1), x(:,2),'Type', 'Spearman')
a=rho^(-1);

corr(x2, x1, 'Type','Spearman');

%---- üũ ---------------
clear all; close all;
X = rand(100,4);
Y = rand(100,4);

plotmatrix(X, Y)  % �������� �������� �׸���. 

[rho,pval] = corr(X,Y)
[rho,pval] = corr(X, 'Type','Spearman');
[rho,pval] = partialcorr(X,'Type','Spearman');
X1 =X(:,1); X2=X(:,2); corr(X1, X2, 'Type','Pearson');
X1 =X(:,1); X2=X(:,2); corrcoef(X1, X2)
%-----------------------
X3=X(:,3); X4 =X(:,4);




% x1= hospital.SexID;
% x2= hospital.Age;
% x3= hospital.Smoker;
% y= hospital.Weight;
%===========================================
% Sensitivity analysis with correlated inputs- an environmental rist... (2004)
% prcc(y, xj) = -c(jy)/ sqrt(c(jj)*c(yy)) 
%===========================================
%% x1, x2, x3�� y�� ��ġ�� ���� ���
prcc_x1 = -a(1, 4)/ sqrt(a(1, 1)*a(4, 4))
prcc_x2 = -a(2, 4)/ sqrt(a(2, 2)*a(4, 4))
prcc_x3 = -a(3, 4)/ sqrt(a(3, 3)*a(4, 4))

%% �ٸ� �����
% clear all
% load hospital ;
% hospital.SexID = grp2idx (hospital.Sex);
% x = [hospital.BloodPressure];
% y = [hospital.Weight hospital.Age];
% z = [hospital.SexID hospital.Smoker];
% 
% [rho,pval] = partialcorr(x,y, z,'Tail','right')
