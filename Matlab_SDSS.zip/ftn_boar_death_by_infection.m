function [boar, num_boar] = ftn_boar_death_by_infection(boar, num_boar,space_size)
s = 0; death_index = [];
for num = 1: num_boar
if (boar(num).age_infection == boar(num).period_infection_to_death)  % �ִ����
    s = s + 1;
    death_index(s,1) = num;
end

end % for
boar(death_index) =[];
[a, num_boar] = size(boar); 