# -*- coding: utf-8 -*-
"""
Created on Tue Mar  9 18:36:18 2021

@author: brook
"""

import matplotlib.pyplot as plt
import matplotlib.image as mpimg
import numpy as np
import pandas as pd
from IPython import display 
from numpy import random as rand
import math
import random
import os, sys
import import_ipynb
from PIL import Image

######## Parameters #################
Color_threshold=250  # color threshold Parameter
WF=9            # Weight of Forest       (it is to be in order as HMM event table )
WFO=8                # Weight of Food
WW=7                 # Weight of water    These can be identify with habitat rank 
# long_mu =20
# long_sigma=5
# short_mu=6
# short_sigma=3
# LS_prob=[0.2,0.8]    # long short probability
# #####
# num_boar=5   #initial boar number
# itr_time=6   # iteration time

### food map
img1=mpimg.imread('D:/Object orinted model/Food_Hw_sq.jpg')   #1km
# img1=mpimg.imread('Food_Hw_square_1000(30m).jpg')
Food=img1[:,:,1]

### forest map
img2=mpimg.imread('D:/Object orinted model/Forest_hw_sq.jpg')
# img2=mpimg.imread('Forest_hw_square1_1000(30m).jpg')
Forest=img2[:,:,1]

## water map 
img3=mpimg.imread('D:/Object orinted model/Water_Hw_sq.jpg')
# img3=mpimg.imread('Water_Hw_square_1000(30m).jpg')
Water=img3[:,:,1]


Water_map=(Water<Color_threshold)*WW
Forest_map=(Forest<Color_threshold)*WF
Food_map=(Food<Color_threshold)*WFO
Map_total=Water_map+Forest_map+Food_map
# Map_total=(Water_map+Forest_map+Food_map).tolist()   # changing to list
x=sorted(np.unique(Map_total),reverse=True)     #Habitat score in Total maps
habitats={'P1':[(1*WF+1*WFO+1*WW)],'P2':[(1*WF+1*WFO+0*WW)],'P3':[(1*WF+0*WFO+1*WW)],'P4':[(1*WF+0*WFO+0*WW)],
      'P5':[(0*WF+1*WFO+1*WW)],'P6':[(0*WF+1*WFO+0*WW)],'P7':[(0*WF+0*WFO+1*WW)],'P8':[(0*WF+0*WFO+0*WW)] }

def get_rand(p):            # find the random number between zero to p 
    #rand.seed(0)
    return int(rand.random()*p)

def Geocoordinates(x,y,xmin,ymin,dx,dy):  #xmin,ymin,xmax,ymax,dx,dy are raster data extent
    px=xmin+x*dx
    py=ymin+y*dy
    return [px,py]

#### determine the movement distance 
def move_distance(self,LS_prob,long_mu,long_sigma,short_mu,short_sigma):
    move_patt= np.random.choice(['L','S'], p = LS_prob)  # set of possible moving  pattern  from pdf
    #set moving distance with normal distribution 
    if move_patt=='L':
        #             P_move_dis=rand.normal(long_mu, long_sigma)
        move_dist=round((rand.random()*long_mu+long_sigma))
        
    else:
        
        move_dist= round((rand.random()*short_mu+short_sigma))
    return move_dist

#select the movement coordinate

def move_ind(self,iteration,move_dist,Map_total):   #val is next moving habitat
    new_environ= self.habi_seq
    # new_environ= self.habi_seq[iteration][0]
    # print(new_environ)
    # print(len(new_environ))
    val=np.array(habitats[new_environ])
    next_pcord=[(index, row.index(val)) for index, row in enumerate(Map_total.tolist()) if val in row]  # next possible coordinate
        #  deterimine the next move cordinate with minimum of distance cell to the movement pattern
    distances=[]
    for cord in next_pcord:
        distance=round(math.dist((self.pos_x,self.pos_y),cord))
        distances.append(distance)     # distances from present to possible cords
    y=[]
    for dis in distances:
        diff_dist=(move_dist-dis)
#             print(diff_dist)
        y.append((diff_dist))
    
    yar=np.array(y)         #changing the y to array
    positive_num_count=sum(1 for i in y if i > 0) 
    negative_num_count=sum(1 for i in y if i < 0)
        ############################################################################################################
    yar=np.array(y)         #changing the y to array
    positive_num_count=sum(1 for i in y if i > 0) 
    negative_num_count=sum(1 for i in y if i < 0)
    ############################################################################################################
    # finding the next coordinate location from 
    if positive_num_count==0:
        min_neg_num=min(abs(yar[yar < 0]))
        cord_locs=move_dist+min_neg_num
    elif negative_num_count==0:
        min_pos_num=min(abs(yar[yar > 0]))
        cord_locs=move_dist-min_pos_num

    elif positive_num_count!=0 and negative_num_count!=0:
        min_neg_num=min(abs(yar[yar < 0]))
        min_pos_num=min(abs(yar[yar > 0]))
        if min_neg_num<min_pos_num:
            cord_locs=move_dist-min_pos_num
        elif min_neg_num==min_pos_num:
            cord_locs=move_dist-min_pos_num
        else:
            cord_locs=move_dist+min_neg_num
    else:
        cord_locs=min(distances)

    ############################################################################################################
    #finding the possible coordinate
    possi_pos=np.where(np.array(distances)==cord_locs)[0][0]
#         print(possi_pos)

    if np.size(possi_pos)==1:
        move_cord=(next_pcord[possi_pos])
    else:
        move_cord=(next_pcord[int(rand.choice((possi_pos),1))])
    self.pos_x=move_cord[0]
    self.pos_y=move_cord[1]
    self.moved=cord_locs

        
# fig,ax=plt.subplots()    
# ax.imshow(np.asarray(Map_total))
# ax.colorbar()
# plt.plt.show()
# plt.axis('off')







