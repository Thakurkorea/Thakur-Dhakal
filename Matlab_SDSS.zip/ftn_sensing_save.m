function  [sens_map] = ftn_sensing_save(r,map)
% map: matrix, position = x-y-axis from left-up 

L = size(map);
sens_map = zeros(L(1)+2,L(2)+2); 

for i=1:L(1)+2
    for j=1:L(2)+2
       sens_map(i,j) = ftn_sensing(i,j,r,map);
    end
end

end