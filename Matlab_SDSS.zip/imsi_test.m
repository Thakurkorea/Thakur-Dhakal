load boar_ini_lat_long.mat;
for k = 1: length(boar_ini_lat_long)
 [grid_x, grid_y] = ftn_lat_long_to_xy(boar_ini_lat_long(k,1), boar_ini_lat_long(k, 2), space_size);
boar_ini_xy(k, 1) = grid_x;
boar_ini_xy(k, 2) = grid_y;

end % k 

hold on ;
im = imread('SKorea_1000.png');
imagesc(im)
ax = gca;
ax.YDir = 'reverse';
plot(boar_ini_xy(:, 1), boar_ini_xy(:,2), 'r*')

