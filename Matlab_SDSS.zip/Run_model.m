clear
tic
ftn_Main_run_HUNTER(10,40,5,1,[0-1],0.01,0.1,0.2)  %(s_time,n_boar,repeat, H0, beta, Pe, Pj, Ph)
toc