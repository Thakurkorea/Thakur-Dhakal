function [U,cln] = ftn_boar_stat_table(U,a1,b,cln)

for i=1:length(a1)
idx = find(strcmp(U(:,1), a1{i}));
U(idx,cln) = num2cell(b{i});
end

cln = cln+1;