# -*- coding: utf-8 -*-
"""
Created on Sun Jun  6 16:36:26 2021

@author: brook
"""

# # importing raster data
# import geopandas as gpd
# import pyproj
# import numpy as np
# import matplotlib
# import matplotlib.pyplot as plt
# import plotly.express as px
# from plotly.offline import download_plotlyjs, init_notebook_mode,  plot,iplot
# init_notebook_mode(connected=False)

# # path=raster = r"D:\Qgis doc\Hwasung point\Hwangsaun gun layers\Forest.shp"
# # Forest_data = gpd.read_file("D:\Qgis doc\Hwasung point\Hwangsaun gun layers\Forest.shp")



# df = px.data.tips()
# fig = px.scatter(df, x="total_bill", y="tip", facet_col="sex",
#                  width=800, height=400)

# fig.update_layout(
#     margin=dict(l=20, r=20, t=20, b=20),
#     paper_bgcolor="LightSteelBlue")


# plot(fig,show_link = True)


import numpy as np 
import geopandas as gpd
from osgeo import gdal
import descartes
from shapely.geometry import Point, Polygon
import matplotlib.pyplot as plt
import contextily as ctx
%matplotlib inline
# register all of the drivers
gdal.AllRegister()
# Open raster data 
df=gdal.Open(f"D:/Qgis doc/Hwasung point/PM_raster.tif")
# df=gdal.Open('D:/IBM/My_model_prac\Chung_hw_map/chungbully _hw.shp')
# df=gdal.Open('C:/Users/brook\Downloads/tif_files/300x300/Forest.tif')   # photo files
# Dimensions 
# df.RasterXSize,df.RasterYSize, df.GetProjection(),df.RasterCount
band = df.GetRasterBand(1)
#  find raster top left, x-pix, top left y, y_pix,roation angle, pix_resolution 5 properties
transform = df.GetGeoTransform()
# change image to array

data = band.ReadAsArray()
# set no data value as -9999
band.SetNoDataValue(-9999)
# gdal.Translate('hi.asci',band,format='asci',projWin=[transform[0],transform[1],transform[2],transform[4]])
#let's save the file in asc file 
# gdal_translate "D:/Qgis doc/Hwasung point/PM_raster.tif" -of AAIGrid "existingascraster.asc"



x=[127.8065531,127.8165531,127.81665531,127.8265531]
y=[37.63887227,37.64887227,37.64987227,37.65887227]
color=['red','black','blue','green']
Points=[Point(xy) for xy in zip(x,y)]
# fig,ax=plt.subplots()
fig,[ax,ax1]=plt.subplots(1,2)  # for fig spilting
# world = gpd.read_file(gpd.datasets.get_path('naturalearth_lowres'))
# world = gpd.read_file(gpd.datasets.get_path('D:/IBM/My_model_prac/Chung_hw_map/chungbully _hw.shp'))   #heonseoan area map 
world = gpd.read_file(gpd.datasets.get_path('naturalearth_lowres'))
korea=gpd.read_file(gpd.datasets.get_path('naturalearth_lowres'))
# ax = world[world.continent == 'Asia'].plot(ax=ax,color='white', edgecolor='black')
AOI= world.plot(ax=ax)
# Korea = world[world.name == 'South Korea'].plot(ax=ax,color='white', edgecolor='black')
crs={'init':'epsg:4326'}    #  set the crs for geo file 

# ctx.add_basemap(ax)
crs = {'init':'epsg:3857'}
Geo_df=gpd.GeoDataFrame(crs=crs,geometry=Points)
crs = Geo_df.to_crs(epsg=3857)
pt=Geo_df.plot(ax=ax1,color=color)







