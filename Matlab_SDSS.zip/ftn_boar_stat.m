function [a1,b,fdx] = ftn_boar_stat(Ad,Ad0,boar)

addr =[]; pos =[];
for i=1: size(boar,2)
%   [WX(i), WY(i)] = ftn_xy_to_lat_long(boar(i).position(1), boar(i).position(2), space_size); 
 %   ftn_xy_to_lat_long(boar(i).position(1), boar(i).position(2), space_size); 

  if ~(strcmp(Ad{boar(i).position(2), boar(i).position(1)},'empt'))
     addr =[addr; Ad{boar(i).position(2), boar(i).position(1)}];
     pos =[pos; {boar(i).position(1), boar(i).position(2)}];
  end

end
  
a1 = {}; b={}; fdx ={};

if ~(length(addr) == 0)
  [a1,a2,a3]=unique(addr,'stable');
  b=cellfun(@(x) sum(ismember(addr,x)),a1,'un',0);

  for i=1:length(a1)
      fdt = find(a3 ==i);
      fdx(i,:) = pos(fdt(1),:);  
%       fdx{i,1} = str2double(table2array(Ad0{fdx{i,1}+1,1}));
%       fdx{i,2} = str2double(table2array(Ad0{1,fdx{i,2}+1}));
       fdx{i,1} = Ad0{fdx{i,1}+1,1};
       fdx{i,2} = Ad0{1,fdx{i,2}+1};

  end
  
  
%   for i=1:length(a1)
%   {a1{i},b{i},b{i}/size(boar,2), fdx(i,:)}
%   end
end