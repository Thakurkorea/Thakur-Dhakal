function [boar, num_boar] = ftn_boar_capacity_death(boar, num_boar, space_size)

Map_boar = zeros(space_size);

for num = 1: num_boar
 Map_boar(boar(num).position(2), boar(num).position(1)) =1;
end % for num

s = 0; death_index = [];
for num = 1: num_boar
    boar_x = boar(num).position(1);
    boar_y = boar(num).position(2);
   
    sensing_r = boar(num).sensing_r;
    [num_boar_in_r] = ftn_sensing(boar_x, boar_y,sensing_r, Map_boar);
    if (num_boar_in_r > boar(num).num_boar_capacity)  %
        s = s + 1;
        death_index(s,1) = num;
    
    end
    
end % for

boar(death_index) =[];
[a, num_boar] = size(boar);


