# -*- coding: utf-8 -*-
"""
Created on Mon Jun 28 18:16:47 2021

@author: brook
"""

# from PIL import Image
# import glob

# # Create the frames
# frames = []
# imgs = glob.glob("*.png")
# for i in imgs:
#     new_frame = Image.open(i)
#     frames.append(new_frame)

# # Save into a GIF file that loops forever
# frames[0].save('png_to_gif.gif', format='GIF',
#                 append_images=frames[1:],
#                 save_all=True,
#                 duration=300, loop=0)



# D:/Qgis doc/Basemap/Administration/korea_admsgg_2017.shp.xml


import geopandas as gpd
from shapely.geometry import Point, Polygon
import matplotlib.pyplot as plt
import descartes
import numpy.random as rand
from celluloid import Camera
fig,[ax1,ax2]=plt.subplots(1,2)

land_cv = gpd.read_file('D:/IBM/My_model_prac/Chung_hw_map/chungbully _hw.shp') #landcover based on chungbuullu
forest= gpd.read_file('D:/IBM/My_model_prac/Chung_hw_map/forest_map.shp')
boundary=gpd.read_file('D:/IBM/My_model_prac/Chung_hw_map/local_boundary.shp')
land_data= land_cv.to_crs({'init': 'epsg:4326'})
loc_bound= boundary.to_crs({'init': 'epsg:4326'})       # local boundary map
forest= forest.to_crs({'init': 'epsg:4326'})       # local boundary map

camera = Camera(fig)
yyy=[]
tim=[]
for i in range(10):
    # world.plot(ax=ax1).axis('off')
    forest.plot(ax=ax1)
    x=rand.uniform(127.8,128.1,5)
    y=rand.uniform(37.35,37.65,5)
    yy=rand.randint(4,10)
    
    yyy.append(yy)
    tim.append(i)
    ax2.plot(tim,yyy)
    ax2.set_title('Total Population')
    # x=[127.85,128.02]
    # y=[37.42,37.51]
    Points=[Point(xy) for xy in zip(x,y)]
    crs = {'init':'epsg:4326'}
    Geo_df=gpd.GeoDataFrame(crs=crs,geometry=Points)
    pt=Geo_df.plot(ax=ax1,color='red')
    ax1.set_title('Position of Boars')
    ax2.legend([f'Day {i}'])
    ax2.set_xlabel('Time (Day)')
    ax2.set_ylabel('No of Boars')
    # boundary.plot(ax=ax2)1
    camera.snap()
#Applying the animate method to create animations
# animation1 = camera.animate(interval = 200, repeat = True, repeat_delay = 500)
animation1 = camera.animate()
# plt.show(animation1)
#Saving the animation
animation1.save('my_movie.gif')



import PIL.Image as pilimg
import matplotlib.pyplot as plt
import numpy as np

image = pilimg.open('D:/IBM/IBM racoon/20201021_090326/jeju_laster_final_cut.tif')
dis_road=pilimg.open("D:/Qgis doc/All raster maps/Raster_data/road_dis/road_dis30m.tif")
image = np.array(image)
dis_raod = np.array(dis_road)