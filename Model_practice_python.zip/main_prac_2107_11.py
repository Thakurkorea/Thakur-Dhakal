# -*- coding: utf-8 -*-
"""
Set attributs id,pos_x,pos_y, age, sex,fertility, pregnant, pregnancy, status, offspring,death,num,month
Consider birth rate
consider carrying capacity
consider allee effect
consider long and short move
consider movement pattern using HMM from observed data
consider groupinig
consider infection period =1 week
immune accoured after 3 weeks from infection 
infected host refection infecious until death
carcass removal is considered 
hunting effect considered 

@author: brook
"""
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
import numpy as np
from numpy import random as rand
from celluloid import Camera
#from matplotlib.animation import FuncAnimation,PillowWriter,ArtistAnimation
from matplotlib import style
import math
import copy
#from scipy import stats
import os, sys
import ffmpeg
import seaborn as sns
import geopandas as gpd
import pandas as pd
from shapely.geometry import Point, Polygon
import descartes
style.use('seaborn-whitegrid')
sns.set()
from  map_and_movement import*
import time
import folium
import csv
# from selenium import webdriver
# import plotly.express as px
# from plotly.offline import download_plotlyjs, init_notebook_mode,  plot,plot_mpl
# from plotly.io import write_image 
# from plotly.io import to_image
from IPython.display import Image
from IPython import get_ipython

# init_notebook_mode()
# init_notebook_mode(connected=True)
start=time.time()
# %matplotlib qt 
# %matplotlib inline

class Boar:
    col={'male':['#0D39EA'], 'female': ['#f70af7'], 'liter':['#339273'], \
         'suspectible': ['#f2f542'], 'infected':['#F31F35'], 'death':['#060505'] }           # color of different individuals
    # blue,pink,green, yellow,red,black
    #age_ratio={0.50:[0,12],	0.27:[13,24],0.23:[24,170]}
   
    def __init__(self,id,pos_x,pos_y, age, sex,fertility, pregnant, pregnancy, offspring,status,\
                 death,month,season, group, repeat,num):
        self.id=id
        self.pos_x=pos_x
        self.pos_y=pos_y
        self.age=age                          # age in month
        self.sex=sex
        self.fertility=fertility              # fertility popwer (yes, no, female_fert %)
        self.pregnant=pregnant
        self.pregnancy=pregnancy
        self.status=status                    # health status 'suspectible','infected','Removed'
        self.offspring=offspring              # have baby or not
        self.death=death
        self.month=month
        self.season=season
        self.color=[]
        self.group=group
        self.repeat=repeat
        self.num=num
        self.mate_time=[]   
        self.pregnancy_time=[]              # laying baby period
        self.lStage=[]                      #life state liter, yourng, old
        self .habi_seq=[]                   # possible move habitat sequences 
        self.state=[]                       # states
        self.moved=[]                       # move_distance
        self.infect_time=0
        self.h_killtime=[]
        
       
    def move_seq(self,TPM,EPM):
        habi_alphabet = ["P1"],["P2"] ,["P3"],["P4"],["P7"],["P8"] # The alphabet of emission
        TPM=TPM/(TPM.sum(axis=1,keepdims=1))      #normalizing to set sum 1
        EPM=EPM/(EPM.sum(axis=1,keepdims=1))
        states = len(EPM)# The no of the states 
        if self.repeat==0:
            self.state=rand.choice(states,1)[0]
            habi = rand.choice(len(habi_alphabet), p = EPM[self.state])
            self.habi_seq=habi_alphabet[habi][0]
        else:
            self.state=rand.choice(states, p = TPM[self.state])
            habi = rand.choice(len(habi_alphabet), p = EPM[self.state])[0]
            self.habi_seq=habi_alphabet[habi]           
            
        
       
    # def move_seq(self,TPM,EPM,tot_itr):
    #     habi_alphabet = ["P1"],["P2"] ,["P3"],["P4"],["P7"],["P8"] # The alphabet of emission
    #     states = len(EPM)# The no of the states 
    #     current_state=rand.choice(states,1)[0]                          
    #     TPM=TPM/(TPM.sum(axis=1,keepdims=1))
    #     EPM=EPM/(EPM.sum(axis=1,keepdims=1))
    #     simulated_sites = [] # start with an empty sequence
    #     simulated_states =[current_state] # to record the sequence of stat
        
    #     for i in range(tot_itr):
    #         current_state = rand.choice(states, p = TPM[current_state])
    #         # choose a new state at site i, weighted by the emission probability matrix
    #         habi = rand.choice(len(habi_alphabet), p = EPM[current_state])
    #         simulated_states.append([current_state])
    #         simulated_sites.append(habi_alphabet[habi])
    #     return [simulated_sites,simulated_states]   
            
            # self.habi_seq=simulated_sites
            # self.state=simulated_states
    # def HMM_move(self,itern):
    #     if self.habi_seq[itern]==['P1']:]
        
    def neighbour(self,boars,neigh_radius):
        cont=0     #counting the neighbours
        neighbours=[]
        for ii in range(len(boars)):
            if self.id!=boars[ii].id:
                 distance=math.dist([self.pos_x,self.pos_y],[boars[ii].pos_x,boars[ii].pos_y])   
                 if distance<=neigh_radius:
                     cont+=1
                     neighbours.append(boars[ii])
        return cont, neighbours  
    
    def det_gender(self,R):          # R is male-female ration [ro, 1-ro]
        gender=['male','female']
        self.sex= rand.choice(gender, p = R)

 
    def det_init_status(self,infected_prop):
         Status=['suspectible','infected','removed']
         if rand.random()< infected_prop or self.age==0:   # 0.030 % 
                 self.status= Status[1]
                 self.infect_time=0
         else:
             self.status= Status[0] 
             
    def update_status(self,boars):
         for br in boars:
             # print('the status is {} & {}'.format( br.status,self.status))
             # print(self.pos_x==br.pos_x and self.pos_y==br.pos_y)
             if br.infect_time>=6 and rand.random()*100<= 50:             # need to modify later                   
                  br.status='removed'
             if [[self.status+br.status] == 'infectedsuspectible' or \
                
                 [self.status+br.status]== 'suspectibleinfected'] and \
                      math.dist([self.pos_x,self.pos_y],[br.pos_x,br.pos_y])==0: 
                          if rand.random()*100<= tran_rate:                                #disease transmission transmission        
                             self.status = 'infected'
                             br.status='infected'
                             self.infect_time+=1
                             if self.infect_time>=6:                                    # died after 6 days
                                 self.status='removed'
                             else:
                                pass
             else:
                pass
             
        #check fertility status        
    def det_fertility(self, min_mating_age,fertility_rate):                   #FR: fertility rate and determine  
        #mating_season=input("mating_season('winter','spring','summer','autumn')")
        if int(self.age)>=min_mating_age and self.sex=='female' and self.season=='autumn' and rand.random()<=fertility_rate:
            self.fertility ='True'
            
        else:
            self.fertility ='False'
    # determine pregnant            
    def det_pregnant(self, pregnant_rate):
        if self.fertility=='True' and rand.random()<=pregnant_rate:
            self.pregnant='True'
            self.mate_time=self.repeat
        else:
            self.pregnant='False'
            self.mate_time='None'
                
    # determine pregnancy    
    def det_pregnancy(self, gastation_time):
        if self.pregnant=='True' and self.repeat==(int(gastation_time)+int(self.mate_time)):
            self.pregnancy_time=self.repeat
            self.pregnancy='True'
                    
        else:
            self.pregnancy_time='None'
            self.pregnancy='False'   
     # produce baby     
    def give_birth(self, offs_range,offs_prob,pregnancy_period):         # offspring range and probabilities, period
         if self.pregnancy=='True' and self.pregnancy_time<=self.repeat<=(self.pregnancy_time+pregnancy_period):
            self.offspring= rand.choice(offs_range, p = offs_prob)
         elif  self.sex=='female' and self.age>=6: # and rand.random()>=40:                                                              #neeed to be refiined
            self.offspring=self.offspring= rand.choice(offs_range, p = offs_prob)
         else:
             self.offspring=0
         liters=[]
         for child in range(self.offspring):
            baby=Boar(-1 ,self.pos_x,self.pos_y,0,[],0,0,0,child,'suspectible','False',[],[],'baby',self.repeat,[len(boars)+1])
            # baby.id=str(self.id)+'.{}'.format(child+1)
            baby.pos_x=get_rand(Plot_size[0])
            baby.pos_y=get_rand(Plot_size[1])
            baby.det_gender(sex_ratio)
            baby.month=self.month
            baby.season=self.season
            baby.lStage='liter'
            # print(self.repeat)
            [baby.habi_seq, baby.state]=[self.habi_seq,self.state]
            # [baby.habi_seq[self.repeat:], baby.state[self.repeat:]]=baby.move_seq(TPM,EPM,(simulation_time-self.repeat)) # different moving sequence 
            # print(baby.habi_seq)
            # [baby.habi_seq, baby.state]=baby.move_seq(TPM,EPM,(simulation_time-self.repeat))
            # baby.habi_seq[self.repeat:]=baby.move_seq(TPM,EPM,(simulation_time-self.repeat))
            # baby.move_seq(TPM,EPM,(simulation_time-self.repeat))
            baby.moved=[]
            # baby.habi_seq=baby.move_seq(TPM,EPM,(simulation_time-self.repeat))
            # baby.habi_seq=self.habi_seq
            baby.set_color()        
            liters.append(baby)
            child=copy.deepcopy(baby)
            boars.append(child)
    def det_death(self):
        if self.status=='removed':
            self.death='true'
        elif self.age>=max_life_span:
            self.death='true'
        else:
            self.death='false'
       
    def set_color(self):
        if self.sex=='male':
            self.color=Boar.col['male']
        else:
             self.color=Boar.col['female']
        if self.lStage=='liter':
            self.color=Boar.col['liter']
        # if self.status=='suspectible':
        #     self.color=Boar.col['suspectible']
        if self.status=='infected':
            self.color=Boar.col['infected']   
        if self.death=='True':
             self.color=Boar.col['death']  
    # def check_dis_status(self,boars):
    
# =============================================================================
#    Make hunter calss             
# =============================================================================
          
class Hunter:
      def __init__(self,Id,x,y,hunt_kill,hunt_num,repeat):
          self.Id=Id
          self.x=x
          self.y=y
          self.hunt_kill=hunt_kill # inteter 12
          self.hunt_num=hunt_num
          self.repeat=repeat
          
        #hunter will kill the boars with certanin probability that lie in the same cell
      def hunter_kill_boar(self,baors,brmowit_hunter):
          for i in range(len(boars)):
              if math.dist([self.x,self.y],[boars[i].pos_x,boars[i].pos_y])<=1 and rand.random()<=0.2: #2 is 2*30meters and 50% chance to kill
                  self.hunt_num+=1
                  boars[i].status='removed'
              else:
                  if boars[i].moved==[]:
                    boars[i].moved=0 
                  (boars[i].moved)+=brmowit_hunter
      def hunter_move(self):
          self.x=get_rand(Plot_size[0])
          self.y=get_rand(Plot_size[1])
            
            
#             for a,b in zip(hunters,boars):
#                 if (a.x,a.y)==(b.x,b.y):
#                     b.status='Removed'
#                     a.hunt_kill+=1
            
        

# def det_month(iteration,this_month,age_count):        # determine the month for simulation
def det_month(self,iteration,this_month):        # determine the month for simulation
    months = ['January', 'February', 'March', 'April', 'May', 'June', 'July',
          'August', 'September', 'October', 'November', 'December']
   
    month_idenitfer=int((this_month-1+iteration*12/365)%12)
    month=months[month_idenitfer]
    age_count=(iteration//(365/12))                            #how old is the boar
    self.month=month
    # self.age=age_count+self.age
def det_season(self):                      # determine the season based on month
    if self.month in ('January', 'February', 'March'):
    	self.season = 'winter'
    elif self.month in ('April', 'May', 'June'):
    	self.season = 'spring'
    elif self.month in ('July', 'August', 'September'):
    	self.season = 'summer'
    else:
    	self.season = 'autumn'
   

def get_age(self,age_ratio):           # function for initial age determine
    ini_age=age_ratio[rand.choice(list(age_ratio),p=list(age_ratio))]
    self.age=rand.choice(range(ini_age[0],ini_age[1]))
    if self.age<=2:
        self.lStage='liter'
    else:
        self.lStage='young'
           
    if self.age<=12:
        self.cata='Piglet'
    elif 12<self.age<=24:
        self.cata='Yearling'
    else:
        self.cata='Adult'
                  
def carry_capa(cont,neighbours,carry_cap_num,boars):
    if cont>=carry_cap_num:
        death_due_carr_cap=cont-carry_cap_num
        death_ind=rand.choice(neighbours,death_due_carr_cap)  #death individual due to carrying capacity
        # print(death_ind)                                    #to 
        for n in range(len(death_ind)):
             for boar in boars:
                if boar.num==death_ind[n].num:
                    boar.status='removed'
                    # boars.remove(boar)
        # return boars            
    else:
        pass              
def allee_capa(boars,allee_num,allee_radius):
   for boar in boars:
       [allee_count, neig]=boar.neighbour(boars,allee_radius)
       if allee_count<=allee_num:
           print('There are just {} boars need more mangement to increase growth'.format(allee_count))
       else:
            pass 

        
# =============================================================================
# # def Plot_ind(boars,t):
# #         xycolor={'x':[],'y':[],'colr':[],'text':[],'sexx':[]}
# #         for boar in boars:
# #             [GX,GY]=Geocoordinates(boar.pos_x, boar.pos_y,extent['xmin'],extent['ymin'],extent['dx'],extent['dy'])
# #             xycolor['x'].append(GX)
# #             xycolor['y'].append(GY)
# #             xycolor['colr'].append(boar.color[0])
# #             xycolor['text'].append(boar.lStage)
# #             xycolor['sexx'].append(boar.sex)
#             
# #         fig = px.scatter_mapbox(xycolor, lat="y", lon="x",zoom=12,color="colr",hover_name="text",labels={"Sex":"Gender","colr": "Color"}, height=400,width=500)
# #         # fig.update_layout(mapbox_style='carto-positron')
# #         fig.update_layout(mapbox_style="open-street-map")
# #         fig.update_layout(margin={"r":0,"t":0,"l":0,"b":0})
# #         fig.layout.update(showlegend=True)
# #         fig.update_layout( title='Boar_simulation', autosize=True)
# #         fig.update_layout(legend=dict(yanchor="top",y=0.99, xanchor="left", x=0.01))
# #         fig.update_layout(showlegend=False)
# #         #crs is EPSG:3857
# #         # fig.show()    
# #         plot(fig,auto_open=True,filename="simtime={} and {}.html".format(t,len(boars)))
 #          plot(fig,auto_open=True,image='png',image_filename=filename,validate=False,auto_play=True,show_link=False,filename=filename)
# #         # cropped_image=pimg(fig,"fine",format="png")
# #         # plt.imshow(cropped_image)
# =============================================================================
'''
plotting with plotly mapbox and imae saving 
'''
# def plot_to_image(fig):
#     if not os.path.exists("images"):
#         os.mkdir("images")
#         fig.ping(f"images/fig{t}.png")
#         img_bytes = fig.to_image(format="png")
#         plt.imshow(img_bytes)
#         Image(img_bytes)
# def Plot_ind(boars,t):          #folium use 
        
#         xycolor={'x':[],'y':[],'colr':[],'text':[],'sexx':[]}
#         for boar in boars:
#             [GX,GY]=Geocoordinates(boar.pos_x, boar.pos_y,extent['xmin'],extent['ymin'],extent['dx'],extent['dy'])
#             xycolor['x'].append(GX)
#             xycolor['y'].append(GY)
#             xycolor['colr'].append(boar.color[0])
#             xycolor['text'].append(boar.lStage)
#             xycolor['sexx'].append(boar.sex)
            
#         fig = px.scatter_mapbox(xycolor, lat="y", lon="x",zoom=12,color="colr",hover_name="text",labels={"Sex":"Gender","colr": "Color"}, height=400,width=500)
#         # camera = Camera(fig)
#         # fig.update_layout(mapbox_style='carto-positron')
#         fig.update_layout(mapbox_style="open-street-map")
#         fig.update_layout(margin={"r":0,"t":0,"l":0,"b":0})
#         fig.layout.update(showlegend=True)
#         fig.update_layout( title='Boar_simulation', autosize=True)
#         fig.update_layout(legend=dict(yanchor="top",y=0.99, xanchor="left", x=0.01))
#         fig.update_layout(showlegend=False)
#         #crs is EPSG:3857
#         fig.show()   
#         # camera.snap()
#         filename="simtime={} and {}.html".format(t,len(boars))
#         plot(fig,auto_open=True,image='png',image_filename=filename,validate=False,auto_play=True,show_link=False,filename=filename)

'''
Plot the boars in each time scan the figure and present total population with scatter diagram in real map

'''
def Plot_ind(boars, fig, camera, b_map, t):          #folium use 
        
        xycolor={'x':[],'y':[],'colr':[],'text':[],'sexx':[]}
        inp=mal_p=fe_p=0                                        #infected male and female population at time t
        for boar in boars:
            [GX,GY]=Geocoordinates(boar.pos_x, boar.pos_y,extent['xmin'],extent['ymin'],extent['dx'],extent['dy'])
            xycolor['x'].append(GX)
            xycolor['y'].append(GY)
            xycolor['colr'].append(boar.color[0])
            xycolor['text'].append(boar.lStage)
            xycolor['sexx'].append(boar.sex)  
            if boar.sex=='female':
                fe_p+=1
            else:
                mal_p+=1
            if boar.status=='infected':
                inp+=1 
        inf_pop.append(inp)
        male_p.append(mal_p)
        fe_p0.append(fe_p)  
        b_map.plot(ax=ax1)
        ax1.set_title('Position of Boars',fontsize=25)
        points=[Point(xy) for xy in zip(xycolor['x'],xycolor['y'])]
        crs = {'init':'epsg:4326'}
        Geo_df=gpd.GeoDataFrame(crs=crs,geometry=points)
        pt=Geo_df.plot(ax=ax1,color=xycolor['colr'])
        # plotting the population count
        pop.append(len(boars))
        tim.append(t)
        ax2.plot(tim,pop,label=f'T.Pop at {t}')
        ax2.plot(tim,male_p,color='#0D39EA',label='Male')
        ax2.plot(tim, fe_p0,color='#f70af7',label='Female')
        ax2.plot(tim, inf_pop,color='#F31F35',label='Infected_pop')
        # ax2.plot(tim,len(boars))    # appears dimentional problem 
        ax2.set_title('Growth Pattern',fontsize=25)
        ax2.legend([f' Pop. on Day {t}'],fontsize=25,loc="upper left")
        ax2.legend([f'Total_pop at: {t}','Male','Female','Infected'],fontsize=25,loc="upper left")
        ax2.set_xlabel('Time (Days)',fontsize=25)
        camera.snap()        # capture the image

# initialize and assign the individuals 

# Plot_size=[310,480]
Plot_size=Map_total.shape
max_life_span=170          #month
sex_ratio=[0.45,0.55]       # sex ratio
age_ratio={0.50:[1,12],	0.27:[13,24],0.23:[24,170]}  #month # percentage:[age limit]#https://link.springer.com/content/pdf/10.1007/s10344-014-0867-3.pdf
offs_range = np.arange(0,9)
offs_prob= [0.012, 0.073, 0.165, 0.242, 0.242, 0.165, 0.073, 0.024, 0.004]; #experimentaldata 
# this_month=input('what month is it (1-12):')        # use input current month
this_month=4                                 #January(1)
fertility_rate=0.65                                 # fertility rate
infected_prop=0.1                          # initial infected proportion
tran_rate=40                       # ranges from [0,100], disease transmission rate
min_mating_age=6                                    #month
pregnant_rate=0.8
gastation_time=114
pregnancy_period=2                                  #month

long_mu =20   # long move mean distance per day                      #20 *30 based on movement data 
long_sigma=2
short_mu=1    # short move mean distance per day 
short_sigma=0.51
LS_prob=[0.2,0.8]    # long short probability
#####

TPM=np.array([
    [0.84, 0.14, 0.02],
    [0.05, 0.91,0.04],
    [0.18,0.39,0.43]])
EPM=np.array([
[0.08,0.21,0.61,0.02,0,0.08],
[0.94,0,0.05,0,0,0],
[0.29,0,0.04,0,0.66,0]])
neigh_radius=0.1  #neighbour radius  n*30*30
allee_num=2    # allee number
allee_radius=10  # radius of allee effect applied area km same ascarrying capacity
carry_cap_num=500 # carrying capacity number equivalent to n/900 in each cell

extent={'xmin':127.83270,'ymin':37.380007071,'dx':0.01,'dy':0.008}  ##crs is EPSG:3857  1km 
# extent={'xmin':127.83270,'ymin':37.380007071,'dx':0.001,'dy':0.0008}  ##crs is EPSG:3857 30m
initial_boars=10
hunters=1
brmowit_hunter=5                    #boar_escape distance 5*30 meter
simulation_time=10
pop=[]      # total population
[inf_pop,male_p,fe_p0]=[[],[],[]]
tim=[]      # to save current simulation time
b=[]    #no of boars at time t
boars=[]    # updated boars
record_boars=[]        # black box to record all boars
land_cv = gpd.read_file('D:/IBM/My_model_prac/Chung_hw_map/chungbully _hw.shp') #landcover based on chungbuullu
forest= gpd.read_file('D:/IBM/My_model_prac/Chung_hw_map/forest_map.shp')
boundary=gpd.read_file('D:/IBM/My_model_prac/Chung_hw_map/local_boundary.shp')
# b_map= land_cv.to_crs({'init': 'epsg:4326'})
b_map= boundary.to_crs({'init': 'epsg:4326'})       # local boundary map
# b_map= forest.to_crs({'init': 'epsg:4326'})       # local boundary map


def initialize_boars(t,initial_boars):
    init_ind=initial_boars
    for i in range(init_ind):
        boar=Boar(i,get_rand(Plot_size[0]),get_rand(Plot_size[1]),[],[],[],[],[],[],[],[],[],[],[],t,[])
        for i in range(int(simulation_time/3)):
            boar=Boar(i,1,1,[],[],[],[],[],[],[],[],[],[],[],t,[])
        for i in range(int(simulation_time/3),int(simulation_time/2)):
            boar=Boar(i,5,5,[],[],[],[],[],[],[],[],[],[],[],t,[])
        get_age(boar,age_ratio)
        boar.det_gender(sex_ratio)
        boar.det_fertility(min_mating_age,fertility_rate)
        boar.det_pregnant(pregnant_rate)
        boar.det_pregnancy(gastation_time)
        
        #boar.give_birth(offs_range,offs_prob,pregnancy_period)
        det_month(boar,t, this_month)                          #age, month, season
        boar.det_death()
        det_season(boar)
        boar.det_init_status(infected_prop)
        boar.group=[]
        boar.set_color()
        # [boar.habi_seq, boar.state]=boar.move_seq(TPM,EPM,simulation_time) # when all sequences included together
        boar.move_seq(TPM,EPM)
        boar.num=len(boars)+1
        boar.neighbour(boars,neigh_radius)
        boars.append(boar)
        rec_boar=copy.deepcopy(boar)                    #deep copy for black box save
        record_boars.append(rec_boar)
       # print(boar.id,boar.age, boar.pos_x,boar.pos_y,boar.num)  
        # Plot_ind(boars,t)
        Plot_ind(boars,fig, camera, b_map, t)
        b.append(len(boars))
        # plt.show
    print(len(boars))
def call_hunter(t,hunters,boars):
    for i in range(hunters):
        hunter=Hunter(i,[],[],[],i+1,t)
        hunter.hunter_move()
        hunter.hunter_kill_boar(boars,brmowit_hunter)
        print('hunter kill boar was {}'.format(hunter.hunt_kill))
       
def update_liters(boars):
    ids=[]
    for boar in boars:
        ids.append(int(boar.id))
        if boar.lStage=='liter' and boar.age>2:
            boar.id=(np.max(ids))+1
            boar.lStage='young'
        if boar.age<=12:
            boar.cata='Piglet'
        elif 12<boar.age<=24:
            boar.cata='Yearling'
        else:
            boar.cata='Adult'
            

            
def update_boars(simulation_time,boars):
    for t in range(1,simulation_time):
        for boar in boars:
            if boar.status!='removed':
                move_dist=move_distance(boar,LS_prob,long_mu,long_sigma,short_mu,short_sigma)
                boar.id=boar.id
                # print(boar.id)
                move_ind(boar,t,move_dist,Map_total)
                # if boar.lStage!='liter':
                #     move_ind(boar,t,move_dist,Map_total)
                # # else:
                #     for i in range(len(boars)):
                #         if boar.id==boars[i].id:
                #             boar.pos_x=boars[i].pos_x
                #             boar.pos_y=boars[i].pos_y
                  
                # # boar.pos_x= get_rand(Plot_size[0])
                # # boar.pos_y=get_rand(Plot_size[1])
                boar.sex=boar.sex
                boar.fertility=boar.det_fertility(min_mating_age,fertility_rate)
                boar.pregnant=boar.det_pregnant(pregnant_rate)
                boar.pregnancy=boar.det_pregnancy(gastation_time)
                boar.offspring=boar.give_birth(offs_range,offs_prob,pregnancy_period)
                boar.det_death()            
                boar.age+=1/30
                det_month(boar,t, this_month)
                det_season(boar)
                update_liters(boars)                          # checking the liters status and update the id and points
                boar.group=[]          
                boar.repeat=t
                cont,neighbours=boar.neighbour(boars,neigh_radius)
                carry_capa(cont,neighbours,carry_cap_num,boars)
                call_hunter(t, hunters, boars)
                # boar.num=boar.num
                boar.update_status(boars)
                boar.set_color()
                rec_boar=copy.deepcopy(boar)                    #deep copy for black box save
                record_boars.append(rec_boar)
            else:
                # print('I gona removed')
                boars.remove(boar)
        boar.num=len(boars)                                #lets remove the dead ond
        ## Plot_ind(boars,t)
        if boar.num>=1:
            Plot_ind(boars,fig, camera, b_map, t)        # plotting with video
        else:
            # sys.exit()
            pass
        # plt.show(block=True)
        print(len(boars))
        b.append(len(boars))
     
    
        # print(len(boars))       
# fig,[ax1,ax2]=plt.subplots(2,1, figsize=(20,15))    # set the fgure background

fig,[ax1,ax2]=plt.subplots(1,2,figsize=(40,15))    # set the fgure background
# create dummy values for legend
plt.cla()
Malec = ax1.scatter(128, 37.5, s=25, linewidth=1, c='#0D39EA', edgecolors='none')   #male
Femalec = ax1.scatter(128, 37.5, s=25, linewidth=1, c='#f70af7', edgecolors='none') #female
literc = ax1.scatter(128, 37.5, s=25, linewidth=1, c='#339273', edgecolors='none') #liter
susp = ax1.scatter(128, 37.5, s=25, linewidth=1, c='#f2f542', edgecolors='none') #suspectible
inftc = ax1.scatter(128, 37.5, s=25, linewidth=1, c='#F31F35', edgecolors='none') #infected
# Remv=  ax1.scatter(128, 37.5, s=25, linewidth=1, c='#060505', edgecolors='none')  #death
# plot legend
ax1.legend(handles=[Malec,Femalec,literc,susp,inftc],
             labels=['M', 'F', 'L','S','I'], loc="upper right", fontsize=25)

camera = Camera(fig)
initialize_boars(0,initial_boars)
print('this is field boars')
update_boars(simulation_time,boars)

animation1 = camera.animate(blit=False, interval=10)
# plt.show(animation1)
#Saving the animation
animation1.save('my_movie11.mp4')
# boar.__dict__

    
end=time.time()
print(f"Runtime of the program is {end - start}")

#### saving the data in excel or csv 
def save_data(record_boars):
    a_dict=[]
    for b in record_boars:
        y=b.__dict__
        a_dict.append(y)
    
    # # f = open('dict.csv','w')
    # # f.write(str(dictt))
    # # f.close()
    
    try:
        with open("sim100_30percentinfect.csv", 'w',encoding='UTF8',newline='') as csvfile:
            writer = csv.DictWriter(csvfile,fieldnames=['pos_x','pos_y','moved', 'offspring', 'season',
                    'group', 'death', 'id', 'repeat', 'sex', 'status', 'habi_seq', 'color', 'state',
           'pregnancy_time', 'num', 'mate_time', 'lStage', 'pregnant', 'age', 'pregnancy', 'month',\
               'cata','fertility','h_killtime', 'infect_time'])
            writer.writeheader()
            for data in a_dict:
                writer.writerow(data)
    except IOError:
        print("I/O error")
    
# for boar in record_boars:
#     for i in range(len(record_boars)):
#         if boar.repeat != record_boars[i].repeat:
#             print(boar.habi_seq)

def plot_dishist(record_boars):   #plotting the distance h
    bor_dis=[]
    for boar in record_boars:
        if boar.moved==[]:
            boar.moved=0
        bor_dis.append(boar.moved)
    plt.hist(bor_dis)
    plt.xlabel('Distance(Km/day)')
    plt.ylabel('Frequency')

def print_states(record_boars):
    for br in record_boars:
        yy,col=[],[]
        for b in range(len(record_boars)):
             if record_boars[b].id==br.id and br.id>=0:
                 dis=record_boars[b].moved
                 if dis==[]:
                     dis=0
                 else:
                     dis=dis 
                 yy.append(dis)
                 col.append(br.state)
             else:
                 pass             
        # print(len(col),len(yy))
        
        xx=range(len(yy))
        # plt.scatter(xx,yy,c=col[1:])
        plt.plot(xx,yy)
        plt.scatter(xx,yy,c=col)
        # for a,b,c in zip(xx,yy,col):
        #     plt.scatter(a,b,c=c)
        # # plt.legend(f'{np.unique(col)}')
        plt.xlabel('Time')
        plt.ylabel('Distance')
    plt.show()   

def dis_stat(record_boars):
    mov=[]
    for br in record_boars:
        dis=br.moved
        if dis==[]:
            dis=0
        else:
            pass
        mov.append(dis)
    print(np.mean(mov),np.std(mov))
    
dis_stat(record_boars)    
    
plt.plot(b[10:]), plt.xlabel('Time (Days)'),plt.ylabel('Population')
def growth_rate():
    a=range(len(b[10:]))
    d=b[10:]
    cc=[]
    for i in a:
        if i<len(b[10:])-1:
          diff=d[i+1]-d[i]
          if diff>0:
              cc.append(abs(diff))
          else:
              cc.append(0)
              # cc.append(abs(diff))      
    plt.plot(b[10:]), plt.xlabel('Time (Days)'),plt.ylabel('Population')
    plt.plot(cc), plt.xlabel('Time (Days)'),plt.ylabel('Death_Pop.')
    
plt.plot(np.cumsum(b[10:])), plt.xlabel('Time (Days)'),plt.ylabel('Death Pop.')

def plt_status(record_boars):
    stat=[]
    for boar in record_boars:
        stat.append(boar.status)
    plt.hist(stat)
    plt.ylabel('Frquency')
    
############# save data
    python_file = open('file_name.csv', "w")
    python_file.write(b)
    python_file.close()   
    
    
    