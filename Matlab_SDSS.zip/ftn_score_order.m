function [ordered_score]=ftn_score_order(score)
% example:
% score=[55571       55574       55578
%        55561       55564       55567
%        55551       55554       55557];
% score =[     5     1     7
%      0     2     6
%      4     0     1];
 ordered_score =zeros(3);
 for i=1:9
     [row, col] = find(ismember(score, max(score(:))));
     for j =1:length(row)
         ordered_score(row(j) ,col(j)) =10-i;
     end
     
     score(row, col) = -1;
     if length(find(score == -1)) == 9
         return;
     end
 end