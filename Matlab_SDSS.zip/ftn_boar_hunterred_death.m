
function [boar, num_boar] = ftn_boar_hunterred_death(boar, num_boar,Map_hunter);

s = 0; death_index = [];
for num = 1: num_boar
    boar_x = boar(num).position(1);
    boar_y = boar(num).position(2);
    sensing_r_hunter = boar(num).sensing_r_hunter;
    [num_hunter] = ftn_sensing(boar_x, boar_y,sensing_r_hunter,Map_hunter);
    if (boar(num).death_rate_by_hunter*num_hunter > rand(1))  %
        s = s + 1;
        death_index(s,1) = num;
    end
    
end % for
boar(death_index) =[];
[a, num_boar] = size(boar);