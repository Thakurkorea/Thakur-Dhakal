function [] = ftn_boar_stat_view(a1,b,fdx,boar)
 la = length(a1);

if ~(la == 0)
WX = []; WY =[]; 
 wm=webmap('World Street Map');
 wmcenter(wm,37.5,127,9);
 
a1

% A = 255*ones(64,128,1,'uint8'); % Or use your current marker You can also use geographic coordinates 
% RGB = insertText(A,[1,20],num2str(fdx{i,1}),'TextColor','black','BoxColor','white','Font','LucidaSansDemiBold'); 
% imwrite(RGB,'testfile.png'); 
% wmmarker(42,-73,'Icon','testfile.png','IconScale',2)

 for i=1:la
     WX(i) = fdx{i,1};
     WY(i) = fdx{i,2};
  A = 255*ones(64,128,1,'uint8'); % Or use your current marker You can also use geographic coordinates 
  A1 = insertText(A,[10,1],a1{i},'TextColor','black','BoxColor','white','Font','���ʷҵ���'); 
  A2 = insertText(A1,[50,20],b{i},'TextColor','black','BoxColor','white'); 
  RGB = insertText(A2,[50,40],b{i}/size(boar,2),'TextColor','black','BoxColor','white'); 
  imwrite(RGB,'testfile.png'); 
      h1=wmmarker(wm,fdx{i,1},fdx{i,2},'Icon','testfile.png','IconScale',2 , 'AutoFit',false);
 end
 
 %h1=wmmarker(wm,WX(1:la),WY(1:la),'Description',num2str(fdx{1,1}), 'AutoFit',false);
 pause(2)
 wmremove(h1);
 wmclose(wm)
end