% 	use hmm
tr = [0.95,0.05;
             0.10,0.90];
rng(5,'philox')         
e = [1/6,  1/6,  1/6,  1/6,  1/6,  1/6;
   1/10, 1/10, 1/10, 1/10, 1/10, 1/2;];

 [seq, states] = hmmgenerate(5,tr,e)

[seq, states] = hmmgenerate(100,tr,e,'Symbols',...
        {'one','two','three','four','five','six'},...
         'Statenames',{'fair';'loaded'});