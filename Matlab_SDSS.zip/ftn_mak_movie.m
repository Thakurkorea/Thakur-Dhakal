%function [] = ftn_mak_movie()
video = VideoWriter('yourvideo.avi'); %create the video object
video = VideoWriter('yourvideo.mp4'); 
open(video); %open the file for writing
for ii=1:N %where N is the number of images
  I = imread('the ith image.jpg'); %read the next image
  writeVideo(video,I); %write the image to file
end
close(video); %close the file