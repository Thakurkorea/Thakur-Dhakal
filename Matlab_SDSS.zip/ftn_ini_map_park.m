
% ��ö�� �ڻ�� �ڵ�: ������Ʈ�� �ʱ� ������� �����ϰ� �����Ѵ�. 
function [agent] = ftn_ini_map_park(agent, T0, num_termite, T, nest_pos, food_pos);

for k =1 : num_termite
    ed = 1; tagent(k) = agent(k);
    if ~(isequal(tagent(k).pos, nest_pos) |  isequal(tagent(k).pos, food_pos))
  while(ed == 1)
    if ~(isequal(tagent(k).pos, nest_pos) |  isequal(tagent(k).pos, food_pos))
        [tagent(k)] = ftn_agent_move_to_food(tagent(k), T); 
    elseif (isequal(tagent(k).pos, nest_pos))
        tagent(k).map(nest_pos(1), nest_pos(2)) =0; ed = 0;
    elseif (isequal(tagent(k).pos, food_pos))
         tagent(k).map(food_pos(1), food_pos(2)) = 0; ed = 0;
    end
  end 
  r=randi(2,1);
  if (r == 1) agent(k).map = tagent(k).map;
  else agent(k).map = T-tagent(k).map;
  end

    end %
end %for k =1