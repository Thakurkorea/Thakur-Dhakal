function [areaa] = find_areaa(boar, t)
bp={boar.position};
[aa, bb] = size(bp);
for k =1 : bb
BP (k,:)=bp{k};
end
x = BP(:,1); y = BP(:,2);
color = [1 0 0];
kk= boundary(x, y);
areaa=polyarea(x, y);