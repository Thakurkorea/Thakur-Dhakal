  # -*- coding: utf-8 -*-
"""
Set attributs id,pos_x,pos_y, age, sex,fertility, pregnant, pregnancy, status, offspring,death,num,month
Consider birth rate
consider carrying capacity
consider allee effect
consider long and short move
consider movement pattern using HMM from observed data
consider groupinig
consider infection period =1 week
immune accoured after 3 weeks from infection 
infected host refection infecious until death
carcass removal is considered 
hunting effect considered 





@author: brook
"""
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
import numpy as np
from numpy import random as rand
from celluloid import Camera
from matplotlib.animation import FuncAnimation,PillowWriter,ArtistAnimation
from matplotlib import style
import math
import copy
from scipy import stats
import os, sys
import ffmpeg
import seaborn as sns
style.use('seaborn-whitegrid')
sns.set()


class Boar:
    col={'male':['#0D39EA'], 'female': ['#f70af7'], 'liter':['#339273'], 'suspectible': ['#f2f542'], 'infected':['#F31F35'], 'death':['#060505'] }           # color of different individuals
    # blue,pink,green, yellow,red,black
    #age_ratio={0.50:[0,12],	0.27:[13,24],0.23:[24,170]}
    def __init__(self,id,pos_x,pos_y, age, sex,fertility, pregnant, pregnancy, offspring,status,death,month,season, group, repeat,num):
        self.id=id
        self.pos_x=pos_x
        self.pos_y=pos_y
        self.age=age                          # age in month
        self.sex=sex
        self.fertility=fertility              # fertility popwer (yes, no, female_fert %)
        self.pregnant=pregnant
        self.pregnancy=pregnancy
        self.status=status                    # health status 'suspectible','infected','Removed'
        self.offspring=offspring              # have baby or not
        self.death=death
        self.month=month
        self.season=season
        self.color=[]
        self.group=group
        self.repeat=repeat
        self.num=num
        self.mate_time=[]   
        self.pregnancy_time=[]              # laying baby period
        self.lStage=[]                      #life state liter, yourng, old
        self .habi_seq=[]                   # possible move habitat sequences 
        
    def move_seq(self,TPM,EPM,tot_itr):
        habi_alphabet = ["P1"],["P2"] ,["P3"],["P4"],["P7"],["P8"] # The alphabet of emission
        states = len(EPM)# The no of the states 
        current_state=rand.choice(states,1)[0]                          
        TPM=TPM/(TPM.sum(axis=1,keepdims=1))
        EPM=EPM/(EPM.sum(axis=1,keepdims=1))
        simulated_sites = [] # start with an empty sequence
        #simulated_states =[current_state] # to record the sequence of stat
        for i in range(tot_itr):
            current_state = rand.choice(states, p = TPM[current_state])
            # choose a new state at site i, weighted by the emission probability matrix
            habi = rand.choice(len(habi_alphabet), p = EPM[current_state])
            #simulated_states.append([current_state])
            simulated_sites.append(habi_alphabet[habi])
            self.habi_seq=simulated_sites
        return self.habi_seq
    # def HMM_move(self,itern):
    #     if self.habi_seq[itern]==['P1']:]
    
    def neighbour(self,boars,neigh_radius):
        cont=0     #counting the neighbours
        neighbours=[]
        for ii in range(len(boars)):
            if self.id!=boars[ii].id:
                 distance=math.dist([self.pos_x,self.pos_y],[boars[ii].pos_x,boars[ii].pos_y])   
                 if distance<=neigh_radius:
                     cont+=1
                     neighbours.append(boars[ii])
        return cont, neighbours     

    def update_boars(self):
        self.age+=1/365
        
        
         
    def set_color(self):
        if self.sex=='male':
            self.color=Boar.col['male']
        elif self.sex=='female':
            self.color=Boar.col['female']
            
        elif self.lStage=='liter':
            self.color=Boar.col['liter']
        elif self.status=='suspectible':
            self.color=Boar.col['suspectible']
        elif self.status=='infected':
            self.color=Boar.col['infected']   
        else:
             self.color=Boar.col['death']   

                
              
class Liter(Boar):
    pass

def get_rand(p):            # find the random number between zero to p 
    #rand.seed(0)
    return round(rand.random()*p,3)

def det_gender(R):          # R is male-female ration [ro, 1-ro]
    gender=['male','female']
    return rand.choice(gender, p = R)
def det_month(iteration,this_month,age_count):        # determine the month for simulation
    months = ['January', 'February', 'March', 'April', 'May', 'June', 'July',
          'August', 'September', 'October', 'November', 'December']
   
    month_idenitfer=int(iteration/(365/12)%12)
    month=months[this_month-1+month_idenitfer]
    age_count+=(iteration//(365/12))                            #how old is the boar
    return month, age_count
     
def det_season(month):                      # determine the season based on month
    if month in ('January', 'February', 'March'):
    	season = 'winter'
    elif month in ('April', 'May', 'June'):
    	season = 'spring'
    elif month in ('July', 'August', 'September'):
    	season = 'summer'
    else:
    	season = 'autumn'
    return season


def get_age(age_ratio):           # function for initial age determine
    ini_age=age_ratio[rand.choice(list(age_ratio),p=list(age_ratio))]
    b0_age=rand.choice(ini_age)
    return b0_age


  #determine initial boar disease status

def det_init_status(boars,transmission_rate):
     Status=['suspectible','infected','Removed']
     for boar in boars:
         
         if rand.random()< transmission_rate or boar.age==0:   # 0.030 % 
             boar.status= Status[1]
         else:
             boar.status= Status[0] 

#determine new positions
def det_position():
    pass

#determine fertile boars
def det_fertility(num, boars, min_mating_age,fertility_rate):                   #FR: fertility rate and determine  
    for boar in boars: 
        #input("mating_season('winter','spring','summer','autumn')")
        if int(boar.age)>=min_mating_age and boar.sex=='female' and boar.season=='autumn' and rand.random()<=fertility_rate:
            boar.fertility ='True'
            
        else:
            boar.fertility ='False'
 
# determine pregnant            
def det_pregnant(boars, pregnant_rate):
    for boar in boars: 
        if boar.fertility=='True' and rand.random()<=pregnant_rate:
            boar.pregnant='True'
            boar.mate_time=boar.repeat
        else:
            boar.pregnant='False'
            boar.mate_time='None'

# determine pregnancy    
           
def det_pregnancy(boars, gastation_time):
    for boar in boars:
        if boar.pregnant=='True' and boar.repeat==(int(gastation_time)+int(boar.mate_time)):
            boar.pregnancy_time=boar.repeat
            boar.pregnancy='True'
                    
        else:
            boar.pregnancy_time='None'
            boar.pregnancy='False'
# produce baby     
def give_birth(boars, offs_range,offs_prob,pregnancy_period):         # offspring range and probabilities, period
    for boar in boars:
        if boar.repeat==0:
            boar.offspring=0
        elif  boar.pregnancy=='True' and boar.pregnancy_time<=boar.repeat<=(boar.pregnancy_time+pregnancy_period):
            boar.offspring= rand.choice(offs_range, p = offs_prob)
            babies=[]
            for child in range(boar.offspring):
                baby=Liter(str(boar.id)+str(1),boar.pos_x,boar.pos_y,0,det_gender(MF_ratio),0,0,0,0,
                            'healthy','False',det_month(boar.repeat,boar.month,0),boar.season,boar.col['liter'],
                            'group',boar.repeat,boar.num+1)
                babies.append(baby)
                boars.append(baby)
        else:
            'None'

            
def carry_capa(cont,neighbours,carry_cap_num,boars):
    if cont>=carry_cap_num:
        death_due_carr_cap=cont-carry_cap_num
        death_ind=rand.choice(neighbours,death_due_carr_cap)  #death individual due to carrying capacity
        print(death_ind)
        for n in range(len(death_ind)):
             for boar in boars:
                if boar.num==death_ind[n].num:                              
                    boars.remove(boar)
        return boars            
    else:
        pass              
def allee_capa(boars,allee_num,allee_radius):
   for boar in boars:
       [allee_count, neig]=boar.neighbour(boars,allee_radius)
       if allee_count<=allee_num:
           print('There are just {} boars need more mangement to increase growth'.format(allee_count))
       else:
            pass 
       
                    
# =============================================================================
# def det_distance(boar,boars):
#     for num in range(len(boars)):
#         return (boar.pos_x-boars[num].pos_x)**2 + (boar.pos_y-boars[num].pos_y)**2
# =============================================================================
       
# =============================================================================
# def det_init_status():
#      Status=['suspectible','infected','Removed']
#      if rand.random()< transmission_rate or boar.age==0:   # 0.030 % 
#          boar.status= Status[1]
#      else:
#          boar.status= Status[0]
# =============================================================================
         
# =============================================================================
#          
#          
#      for num in range(len(boars)):
#         contact=math.sqrt((boar.pos_x-boars[num].pos_x)**2 + (boar.pos_y-boars[num].pos_y)**2) <=cont_range
#         if (boar.status+ boar[num].status=='suspectibleinfected' or boar.status+ boar[num].status=='infectedsuspectible') and contact=='True':
#             boar.status=Status[1]
#             boar[num].status=Status[1]
#         elif 
# =============================================================================
            
            
       
# =============================================================================
# def det_contact(boars, cont_range):
#     con_count=0
#     contact=[]
#     for boar in boars:
#         for num in range(len(boars)):
#           if boars[num].id != boar.id:
#              distance= ((boar.pos_x-boars[num].pos_x)**2 + (boar.pos_y-boars[num].pos_y)**2)
#         distance <=cont_range**2
#         con_count+=1
#     return contact,con_count
# =============================================================================
      
    

# initialize and assign the individuals 

Plot_size=[310,480]
max_life_span=5110          #days
MF_ratio=[0.45,0.55]
age_ratio={0.50:[1,12],	0.27:[13,24],0.23:[24,170]}   # percentage:[age limit]
offs_range = np.arange(0,9)
offs_prob= [0.012, 0.073, 0.165, 0.242, 0.242, 0.165, 0.073, 0.024, 0.004]; #실험값참조
# this_month=input('what month is it (1-12):')        # use input current month
this_month=12                                        #January(1)
fertility_rate=0.65                                 # fertility rate
cont_range=3                                        # contact range distance 3 units
transmission_rate=0.03                              # initial disease transmission rate

min_mating_age=6                                    #month
pregnant_rate=0.8
gastation_time=114
pregnancy_period=2                                  #month


TPM=np.array([
    [0.84, 0.14, 0.02],
    [0.05, 0.91,0.04],
    [0.18,0.39,0.43]])
EPM=np.array([
[0.08,0.21,0.61,0.02,0,0.08],
[0.94,0,0.05,0,0,0],
[0.29,0,0.04,0,0.66,0]])
neigh_radius=10  #neighbour radius 
allee_num=2      # allee number
allee_radius=200  # radius of allee effect applied area 
carry_cap_num=10  # carrying capacity number

initial_boars=5
simulation_time=5

boars=[]
record_boars=[]


def simulate_boars(t):
    if t==0:                #field boars creation
        init_ind=initial_boars
        for i in range(init_ind):
            boar=Boar(i,get_rand(Plot_size[0]),get_rand(Plot_size[1]),get_age(age_ratio),det_gender(MF_ratio),det_fertility(i,boars,min_mating_age,fertility_rate),
                      det_pregnant(boars,pregnant_rate), det_pregnancy(boars, gastation_time),give_birth(boars,offs_range,offs_prob,pregnancy_period),det_init_status(boars,transmission_rate)
                      ,0,det_month(t,this_month,get_age(age_ratio))[0],det_season(det_month(t,this_month,get_age(age_ratio))[0]),"A",t,i)  
            boar.move_seq(TPM,EPM,simulation_time)
            boar.set_color()
            boars.append(boar)
            record_boars.append(boar)
        for ii in range(len(boars)):
            plt.scatter(boars[ii].pos_x,boars[ii].pos_y,c=boars[ii].color)
        plt.title('Boars in Environment at t=0')
        # plt.pause(1)
        plt.show()
    else:
        
     for boar in boars:
         for i in range(len(boars)):     
            boar=Boar(i,get_rand(Plot_size[0]),get_rand(Plot_size[1]),get_age(age_ratio),det_gender(MF_ratio),det_fertility(i,boars,min_mating_age,fertility_rate),
                      det_pregnant(boars,pregnant_rate), det_pregnancy(boars, gastation_time),give_birth(boars,offs_range,offs_prob,pregnancy_period),det_init_status(boars,transmission_rate)
                      ,0,det_month(t,this_month,get_age(age_ratio))[0],det_season(det_month(t,this_month,get_age(age_ratio))[0]),"A",t,i)  
            boar.move_seq(TPM,EPM,simulation_time)
            boar.set_color()
            boars.append(boar)
            record_boars.append(boar)
            for ii in range(len(boars)):
                plt.scatter(boars[ii].pos_x,boars[ii].pos_y,c=boars[ii].color)
            # plt.title('Boars in Environment at t={}'.format(t))
         # plt.pause(1)
         plt.show() 
     
        
        
        
        # updated_boars=copy.copy(boars)
        # for boar in updated_boars:
        #     boar.pos_x=get_rand(Plot_size[0])
        #     boar.pos_y=get_rand(Plot_size[0])
        #     boar.id= boar.id
        #     boar.age=det_month(t,this_month,get_age(age_ratio))[0] 
        #     boar.fertility= det_fertility(boar.num,boars,min_mating_age,fertility_rate)            
        #     boar.pregnant=det_pregnant(boars,pregnant_rate)
        #     boar.pregnancy=det_pregnancy(boars, gastation_time)
        #     boar.offspring=give_birth(boars,offs_range,offs_prob,pregnancy_period)
        #     boar.status=det_init_status(boars,transmission_rate)                   #need to change later
        #     boar.death=0
        #     boar.month=det_month(t,this_month,get_age(age_ratio))[0]
        #     boar.season=det_season(det_month(t,this_month,get_age(age_ratio))[0])
        #     boar.group=[]
        #     boar.repeat=t
        #     boar.num= boar.num
        #     boar.set_color()
        #     record_boars.append(boar)
             
        #     for boar in record_boars:
        #           if boar.repeat==t:
        #               plt.scatter(boar.pos_x,boar.pos_y,c=boar.color)
        # plt.title('Boars in Environment at t={}'.format(t))
        #     # plt.pause(1)
        # plt.show()
                 
            
            
for t in range(simulation_time):
    simulate_boars(t)
         
    

# def update_boars():
#     for t in range(1,Simulatin_time):
#         for boar in boars:
#            boar.pos_x=get_rand(Plot_size[0])
#            boar.pos_y=get_rand(Plot_size[1])
#            boars.append(boar)
         
            
    
              
    




# for iiter in range(Simulatin_time):
#     if iiter==0:
#         creat_boars()
#     else:
#         update_boars()
 
# # =============================================================================
    # print(boars)
        

    
# for boar in boars:
#   if boar.age==0:
#     plt.scatter(boar.pos_x,boar.pos_y,100)
# # =============================================================================
# [cont,neighbour]=boar.neighbour(boars,500)
# carry_capa(cont,neighbour,3,boars)



for boar in boars:
    print(boar.id,boar.pos_x,boar.pos_y,boar.age,                         
        boar.sex,
        boar.fertility,             
        boar.pregnant,
        boar.pregnancy,
        boar.status,
        boar.offspring,
        boar.death,
        boar.month,
        boar.season,
        boar.color,
        boar.group,
        boar.repeat,
        boar.num,
        boar.mate_time,
        boar.pregnancy_time)





























# =============================================================================
# 
# # class Boar:
# 
# #     def __init__(self,id,month,pos_x,pos_y,sex='male',age=0,stage='piglet',status='susceptible',infectious=0,immunity=0,expired=0,breeding=False,pregnant=False,litter=0,pregnancy=0,piglets=[]):
# #         self.id=id
# #         self.month= month
# #         self.pos_x=pos_x
# #         self.pos_y=pos_y
# #         self.sex=sex
# #         self.age=age
# #         self.stage=stage
# #         self.status=status
# #         self.infectious=infectious
# #         self.immunity=immunity
# #         if(self.sex=='female'):
# #             self.breeding=breeding
# #             self.fertility=1
# #             self.pregnant=pregnant
# #             self.litter=litter
# #             self.pregnancy=pregnancy
# #             self.piglets=piglets
# #     # def move(self,)
# #     # def aging(self,)
#     
# #     # def periodic_boundary(self,)
#    
# #     # def reproduction(self, ):
# #     # def death_by_infection(self,)
# #     # def boar_hunterred_death(self,)
# #     # def   
# 
#         
# #     # def mortality(self,)
#        
# #     # def dispersal(self,)
#            
# # a=Boar(1,5,6,4,8,7,8,9,7,8,9,5,1,1,2,3)
# =============================================================================
