function [score_hunter_mind] = ftn_score_hunter(hunter_x,hunter_y,sensing_r,Map_hunter_mind)

score_hunter_mind = zeros(3);
[num_hunter_mind] = ftn_sensing(hunter_x-1, hunter_y+1,sensing_r,Map_hunter_mind); score_hunter_mind(1,1)= num_hunter_mind;
[num_hunter_mind] = ftn_sensing(hunter_x-1, hunter_y+0,sensing_r,Map_hunter_mind); score_hunter_mind(2,1)= num_hunter_mind;
[num_hunter_mind] = ftn_sensing(hunter_x-1, hunter_y-1,sensing_r,Map_hunter_mind); score_hunter_mind(3,1)= num_hunter_mind;
[num_hunter_mind] = ftn_sensing(hunter_x+0, hunter_y+1,sensing_r,Map_hunter_mind); score_hunter_mind(1,2)= num_hunter_mind;
[num_hunter_mind] = ftn_sensing(hunter_x+0, hunter_y+0,sensing_r,Map_hunter_mind); score_hunter_mind(2,2)= num_hunter_mind;
[num_hunter_mind] = ftn_sensing(hunter_x+0, hunter_y-1,sensing_r,Map_hunter_mind); score_hunter_mind(3,2)= num_hunter_mind;
[num_hunter_mind] = ftn_sensing(hunter_x+1, hunter_y+1,sensing_r,Map_hunter_mind); score_hunter_mind(1,3)= num_hunter_mind;
[num_hunter_mind] = ftn_sensing(hunter_x+1, hunter_y+0,sensing_r,Map_hunter_mind); score_hunter_mind(2,3)= num_hunter_mind;
[num_hunter_mind] = ftn_sensing(hunter_x+1, hunter_y-1,sensing_r,Map_hunter_mind); score_hunter_mind(3,3)= num_hunter_mind;

