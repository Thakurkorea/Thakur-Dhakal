function [score_forest, score_food, score_water] = ftn_score_save(bx,by,Map_forest, Map_food, Map_water)

bx = bx+1;by = by+1;

score_forest = zeros(3);
[num_forest] = Map_forest(bx-1, by+1); score_forest(1,1)= num_forest;
[num_forest] = Map_forest(bx-1, by+0); score_forest(2,1)= num_forest;
[num_forest] = Map_forest(bx-1, by-1); score_forest(3,1)= num_forest;
[num_forest] = Map_forest(bx+0, by+1); score_forest(1,2)= num_forest;
[num_forest] = Map_forest(bx+0, by+0); score_forest(2,2)= num_forest;
[num_forest] = Map_forest(bx+0, by-1); score_forest(3,2)= num_forest;
[num_forest] = Map_forest(bx+1, by+1); score_forest(1,3)= num_forest;
[num_forest] = Map_forest(bx+1, by+0); score_forest(2,3)= num_forest;
[num_forest] = Map_forest(bx+1, by-1); score_forest(3,3)= num_forest;

score_food = zeros(3);
[num_food] = Map_food(bx-1, by+1); score_food(1,1)= num_food;
[num_food] = Map_food(bx-1, by+0); score_food(2,1)= num_food;
[num_food] = Map_food(bx-1, by-1); score_food(3,1)= num_food;
[num_food] = Map_food(bx+0, by+1); score_food(1,2)= num_food;
[num_food] = Map_food(bx+0, by+0); score_food(2,2)= num_food;
[num_food] = Map_food(bx+0, by-1); score_food(3,2)= num_food;
[num_food] = Map_food(bx+1, by+1); score_food(1,3)= num_food;
[num_food] = Map_food(bx+1, by+0); score_food(2,3)= num_food;
[num_food] = Map_food(bx+1, by-1); score_food(3,3)= num_food;

score_water = zeros(3);
[num_water] = Map_water(bx-1, by+1); score_water(1,1)= num_water;
[num_water] = Map_water(bx-1, by+0); score_water(2,1)= num_water;
[num_water] = Map_water(bx-1, by-1); score_water(3,1)= num_water;
[num_water] = Map_water(bx+0, by+1); score_water(1,2)= num_water;
[num_water] = Map_water(bx+0, by+0); score_water(2,2)= num_water;
[num_water] = Map_water(bx+0, by-1); score_water(3,2)= num_water;
[num_water] = Map_water(bx+1, by+1); score_water(1,3)= num_water;
[num_water] = Map_water(bx+1, by+0); score_water(2,3)= num_water;
[num_water] = Map_water(bx+1, by-1); score_water(3,3)= num_water;
