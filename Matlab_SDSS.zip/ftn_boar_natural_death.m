function [boar, num_boar] = ftn_boar_natural_death(boar, num_boar);
s = 0; death_index = [];
for num = 1: num_boar
if (boar(num).death_rate > rand(1))  % 
    s = s + 1;
    death_index(s,1) = num;
end

end % for
boar(death_index) =[];
[a, num_boar] = size(boar); 