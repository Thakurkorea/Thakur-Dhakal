function [boar_x, boar_y] =ftn_boar_walk(boar, num, Map_forest, Map_food, Map_water)

%% ����� �̿����ڵ��� ���� ����
boar_x = boar(num).position(1);
boar_y = boar(num).position(2);
sensing_r = boar(num).sensing_r;
[score_forest, score_food, score_water] = ...
    ftn_score(boar_x,boar_y,sensing_r,Map_forest, Map_food, Map_water);  
% 
%% �������� --> �̵�Ȯ�� ���
 boar_num = boar(num);
[P_trans] = ftn_score_to_ptrans(boar_num, score_forest, score_food, score_water);

% example:
% P_trans =...
%     [0.0296    0.0499    0.0703
%     0.0907    0.1111    0.1315
%     0.1519    0.1723    0.1927];

r_1 = P_trans(1,1);
r_2 = r_1 + P_trans(2,1);
r_3 = r_2 + P_trans(3,1);
r_4 = r_3 + P_trans(1,2);
r_5 = r_4 + P_trans(2,2);
r_6 = r_5 + P_trans(3,2);
r_7 = r_6 + P_trans(1,3);
r_8 = r_7 + P_trans(2,3);
r_9 = r_8 + P_trans(3,3);

dice = rand(1);

if (dice>=0) & (dice <= r_1)
    boar_x =boar_x-1; boar_y = boar_y+1;  % ���� 1
elseif (dice>r_1) & (dice <= r_2)
    boar_x =boar_x-1; boar_y = boar_y+0; %���� 2
elseif (dice>r_2) & (dice <= r_3)
    boar_x =boar_x-1; boar_y = boar_y-1; %���� 3
elseif (dice>r_3) & (dice <= r_4)
    boar_x =boar_x-0; boar_y = boar_y+1; %���� 4
elseif (dice>r_4) & (dice <= r_5)
    boar_x =boar_x-0; boar_y = boar_y+0; %���� 5
elseif (dice>r_5) & (dice <= r_6)
    boar_x =boar_x-0; boar_y = boar_y-1; %���� 6
elseif (dice>r_6) & (dice <= r_7)
    boar_x =boar_x+1; boar_y = boar_y+1; % ���� 7
elseif (dice>r_7) & (dice <= r_8)
    boar_x =boar_x+1; boar_y = boar_y+0; %���� 8
elseif (dice>r_8) & (dice <= r_9)
    boar_x =boar_x+1; boar_y = boar_y-1; %���� 9
end
    
                    
    