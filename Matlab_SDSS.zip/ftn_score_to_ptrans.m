function [P_trans] = ftn_score_to_ptrans(boar_num, score_forest, score_food, score_water)

%% �������� --> �̵�Ȯ�� ���
[ordered_score_forest]=ftn_score_order(score_forest);
[ordered_score_food]=ftn_score_order(score_food);
[ordered_score_water]=ftn_score_order(score_water);

tot_score = (boar_num.w_forest.*ordered_score_forest)...
          + (boar_num.w_food.*ordered_score_food)...
          + (boar_num.w_water.* ordered_score_water);
T= sum(sum(tot_score));
P_trans = tot_score./T; 
