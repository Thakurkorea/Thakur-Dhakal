
% ay:위도, ax:경도
clear all;
load map_grids_to_lat_long.mat ax ay
for i = 101: 200
    for j = 1: 337
lat_long = ['https://geocode.xyz/' num2str(ay(i)) ',' num2str(ax(j)) '?json=1'];
a=webread(lat_long);   
[i, j]
district_name{i, j} = a;
    end
end
save district_name.mat district_name
% lat_long = "https://geocode.xyz/38.0438,128.708?json=1";
% % newStr = insertAfter(str,"xyz/","128.708")
% a=webread(lat_long);
% a.city